import Reveal from "@/components/Reveal";
import ContactForm from "@/components/ContactForm";
import { LOCATIONS, SITE } from "@/lib/site";

export const metadata = {
  title: "Contact & Clinic Locations | Balark Ayurveda and Panchakarma Clinic",
  description:
    "Two branches — Gandhinagar (Kudasan) and Visnagar. Maps, phone numbers, WhatsApp, email, clinic hours and social media of Balark Ayurveda and Panchakarma Clinic.",
};

export default function Contact() {
  return (
    <>
      <section className="border-b border-brown/10 bg-cream-deep/50 py-16">
        <div className="mx-auto max-w-7xl px-6 text-center">
          <Reveal>
            <p className="text-[0.68rem] font-bold tracking-[0.24em] text-gold uppercase">We are near you</p>
            <h1 className="mt-3 font-display text-[clamp(2.4rem,5vw,4rem)] leading-[1.05] font-semibold text-brown-deep">
              <span className="line-mask"><span>Two clinics, one call away.</span></span>
            </h1>
            <p className="mx-auto mt-4 max-w-2xl text-ink/75">
              Walk in, call, WhatsApp or book online — whichever feels calmest for you.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-16">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {[
            {
              t: "Call the clinic",
              lines: SITE.phones.map((p) => p.label),
              href: SITE.phones[0].href,
              cta: "Call now",
              icon: <path d="M5 4h4l2 5-2.5 1.5a12 12 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z" strokeLinejoin="round" />,
            },
            {
              t: "WhatsApp",
              lines: ["Replies within minutes", "9 AM – 8 PM, Mon–Sat"],
              href: `https://wa.me/${SITE.primaryWhatsapp}`,
              cta: "Open chat",
              icon: <path d="M12 3a9 9 0 0 0-7.8 13.5L3 21l4.6-1.2A9 9 0 1 0 12 3zm4.5 12.2c-.2.6-1.2 1.2-1.7 1.3-.4.1-1 .1-1.6-.1-1.5-.5-2.9-1.5-3.9-2.8-.7-.9-1.2-1.9-1.2-2.8 0-.8.4-1.5.8-1.8.2-.2.5-.2.7-.2h.5c.2 0 .4 0 .5.4l.7 1.7c.1.2.1.3 0 .5l-.5.7c-.1.2-.1.3 0 .5.6 1 1.4 1.7 2.4 2.2.2.1.4.1.5-.1l.6-.7c.2-.2.3-.2.6-.1l1.7.8c.3.1.4.2.4.4 0 .1 0 .5-.1.8z" />,
            },
            {
              t: "Email",
              lines: [SITE.emails.general, SITE.emails.appointments],
              href: `mailto:${SITE.emails.general}`,
              cta: "Write to us",
              icon: <path d="M4 6h16a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1zm0 1.5l8 5.5 8-5.5" />,
            },
            {
              t: "Clinic hours",
              lines: ["Mon–Sat: 9–1 & 4–8", "Sunday: by appointment"],
              href: "#maps",
              cta: "See branches",
              icon: <path d="M12 3a9 9 0 1 0 9 9 9 9 0 0 0-9-9zm0 4v5l3.5 2" strokeLinecap="round" />,
            },
          ].map((c, i) => (
            <Reveal key={c.t} delay={i * 80}>
              <a href={c.href} target={c.href.startsWith("http") ? "_blank" : undefined} rel="noreferrer" className="card-lift block h-full rounded-2xl border border-brown/12 bg-paper p-6">
                <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-sage/12 text-sage-deep">
                  <svg viewBox="0 0 24 24" className="h-5.5 w-5.5 fill-none stroke-current" strokeWidth="1.8">
                    {c.icon}
                  </svg>
                </span>
                <h2 className="mt-4 font-display text-2xl font-semibold text-brown">{c.t}</h2>
                {c.lines.map((l) => (
                  <p key={l} className="mt-1 text-sm text-ink/70">{l}</p>
                ))}
                <p className="mt-4 text-[0.72rem] font-bold tracking-wide text-sage-deep">{c.cta} →</p>
              </a>
            </Reveal>
          ))}
        </div>

        <div className="mt-10 grid gap-6 rounded-2xl border border-brown/12 bg-paper p-6 sm:grid-cols-2">
          <div>
            <p className="text-[0.68rem] font-bold tracking-[0.2em] text-gold uppercase">Follow our daily clinic life</p>
            <div className="mt-4 flex flex-wrap gap-4">
              <a href={SITE.socials.facebook} target="_blank" rel="noreferrer" className="flex items-center gap-3 rounded-xl border border-brown/15 px-5 py-3 transition hover:border-[#1877F2] hover:bg-[#1877F2]/5">
                <svg viewBox="0 0 24 24" className="h-5 w-5 fill-[#1877F2]">
                  <path d="M13.5 21v-7h2.6l.4-3h-3V9.1c0-.9.3-1.5 1.6-1.5h1.5V4.9c-.3 0-1.2-.1-2.2-.1-2.2 0-3.7 1.3-3.7 3.8V11H8v3h2.7v7h2.8z" />
                </svg>
                <span className="text-sm font-bold text-ink/80">/balarkayurveda</span>
              </a>
              <a href={SITE.socials.instagram} target="_blank" rel="noreferrer" className="flex items-center gap-3 rounded-xl border border-brown/15 px-5 py-3 transition hover:border-[#E4405F] hover:bg-[#E4405F]/5">
                <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-[#E4405F]" strokeWidth="2">
                  <rect x="3.5" y="3.5" width="17" height="17" rx="4.5" />
                  <circle cx="12" cy="12" r="3.6" />
                  <circle cx="17.2" cy="6.8" r="1.1" fill="#E4405F" stroke="none" />
                </svg>
                <span className="text-sm font-bold text-ink/80">@balark_ayurveda_and_panchkarma</span>
              </a>
            </div>
          </div>
          <div className="flex items-center justify-center rounded-xl bg-cream-deep/60 p-6 text-center">
            <p className="font-display text-xl text-brown italic">“{SITE.tagline}”</p>
          </div>
        </div>
      </section>

      <section id="maps" className="bg-cream-deep/60 py-16">
        <div className="mx-auto max-w-7xl px-6">
          <Reveal className="text-center">
            <p className="text-[0.68rem] font-bold tracking-[0.24em] text-gold uppercase">Map section</p>
            <h2 className="mt-3 font-display text-4xl font-semibold text-brown-deep">Our two locations</h2>
          </Reveal>
          <div className="mt-10 grid gap-8 lg:grid-cols-2">
            {LOCATIONS.map((l, i) => (
              <Reveal key={l.key} delay={i * 120}>
                <div className="overflow-hidden rounded-3xl border border-brown/12 bg-paper shadow-lg">
                  <iframe
                    src={l.mapEmbed}
                    title={`Google map of ${l.name}`}
                    loading="lazy"
                    allowFullScreen
                    referrerPolicy="strict-origin-when-cross-origin"
                    className="h-96 w-full border-0"
                  />
                  <div className="p-7">
                    <h3 className="font-display text-2xl font-semibold text-brown">{l.name}</h3>
                    <p className="mt-1.5 text-sm leading-relaxed text-ink/70">{l.title}</p>
                    <p className="mt-2 text-sm text-ink/65">{l.address}</p>
                    <p className="mt-1 text-sm font-bold text-sage-deep">{l.phone}</p>
                    <div className="mt-5 flex flex-wrap gap-3">
                      <a href={l.directions} target="_blank" rel="noreferrer" className="rounded-full bg-sage px-6 py-3 text-[0.75rem] font-bold text-cream transition hover:bg-sage-deep">
                        Get Directions
                      </a>
                      <a href={`tel:${l.phone.replace(/\s/g, "")}`} className="rounded-full border-2 border-brown/25 px-6 py-3 text-[0.75rem] font-bold text-brown transition hover:border-gold hover:text-gold">
                        Call this branch
                      </a>
                    </div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-3xl px-6 py-16">
        <Reveal className="text-center">
          <h2 className="font-display text-3xl font-semibold text-brown-deep sm:text-4xl">Send us a message</h2>
          <p className="mt-3 text-ink/70">Your message opens directly in the clinic WhatsApp or email — no waiting.</p>
        </Reveal>
        <Reveal delay={120} className="mt-8">
          <ContactForm />
        </Reveal>
      </section>
    </>
  );
}
