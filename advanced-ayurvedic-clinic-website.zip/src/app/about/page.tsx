import Link from "next/link";
import Reveal from "@/components/Reveal";
import { LogoMark } from "@/components/Logo";
import { SITE } from "@/lib/site";

export const metadata = {
  title: "About Us | Balark Ayurveda and Panchakarma Clinic",
  description:
    "The story, philosophy and facilities of Balark Ayurveda and Panchakarma Clinic — serving Gandhinagar and Visnagar since 2008.",
};

const TIMELINE = [
  { year: "2008", title: "The first consultation room", text: "Dr Chirag Vyas begins practice in Kudasan, Gandhinagar with one promise: treat the root cause, never just the symptom." },
  { year: "2014", title: "In-house pharmacy opens", text: "Balark starts preparing its own specialised Panchakarma oils and the now-famous Balark hair oil formulations." },
  { year: "2018", title: "Visnagar branch welcomes patients", text: "A second clinic opens for Visnagar, bringing joint, spine, hair and skin care closer to north Gujarat." },
  { year: "2022", title: "Dhruva herbal beauty line", text: "Dhruva Vyas launches herbal beauty, skin and hair care products crafted for female patients' needs." },
  { year: "2026", title: "The digital clinic", text: "Online appointment system with instant doctor alerts, AI assistance and WhatsApp care — healing without waiting rooms." },
];

const VALUES = [
  { t: "Root-cause first", d: "Nadi pariksha, history and modern reports together — every protocol begins with why, not what." },
  { t: "Classical, never diluted", d: "Panchakarma performed exactly as the texts prescribe, with purified oils and proper sequencing." },
  { t: "Made in-house", d: "Our own pharmacy means we know every herb, every batch, every drop that touches your skin." },
  { t: "Care that continues", d: "Diet, dinacharya and follow-up calls after therapy — because healing lives in your routine." },
];

const IMG_HERBS =
  "https://images.pexels.com/photos/4871289/pexels-photo-4871289.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200";
const IMG_OILS =
  "https://images.pexels.com/photos/8450228/pexels-photo-8450228.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200";
const IMG_THERAPY =
  "https://images.pexels.com/photos/6629614/pexels-photo-6629614.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200";

export default function About() {
  return (
    <>
      <section className="relative overflow-hidden border-b border-brown/10 bg-cream-deep/50">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-6 py-16 lg:grid-cols-2 lg:py-24">
          <div>
            <Reveal>
              <p className="text-[0.68rem] font-bold tracking-[0.24em] text-gold uppercase">Our story</p>
              <h1 className="mt-3 font-display text-[clamp(2.4rem,5vw,4rem)] leading-[1.05] font-semibold text-brown-deep">
                <span className="line-mask"><span>Eighteen years of</span></span>
                <span className="line-mask" style={{ "--reveal-delay": "120ms" } as React.CSSProperties}>
                  <span>quiet, careful healing.</span>
                </span>
              </h1>
            </Reveal>
            <Reveal delay={200}>
              <p className="mt-6 leading-relaxed text-ink/75">
                {SITE.name} began in {SITE.since} with a single consultation room in Kudasan,
                Gandhinagar. Today, two branches and more than 35,000 treated patients later, the
                promise is unchanged: a holistic approach to health through traditional Ayurvedic
                treatment and Panchakarma therapy — combined with a modern, diagnostic mindset.
              </p>
              <p className="mt-4 leading-relaxed text-ink/75">
                We specialise in joint pain, spinal disorders, arthritis, sciatica, frozen shoulder
                and chronic conditions, alongside detoxification and rejuvenation therapies such as
                Vaman Karma, Virechan Karma and Shirodhara, and personalised care for digestive,
                respiratory and lifestyle diseases.
              </p>
            </Reveal>
            <Reveal delay={300}>
              <div className="mt-8 flex flex-wrap gap-4">
                <Link href="/doctors" className="rounded-full bg-sage px-7 py-3.5 text-sm font-bold text-cream transition hover:-translate-y-0.5 hover:bg-sage-deep">
                  Meet the doctors
                </Link>
                <Link href="/book" className="rounded-full border-2 border-brown/25 px-7 py-3.5 text-sm font-bold text-brown transition hover:-translate-y-0.5 hover:border-gold hover:text-gold">
                  Book a consultation
                </Link>
              </div>
            </Reveal>
          </div>
          <Reveal delay={150} className="relative">
            <div className="grid grid-cols-2 gap-4">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={IMG_THERAPY} alt="Panchakarma oil therapy" className="arch h-72 w-full object-cover shadow-xl" />
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={IMG_HERBS} alt="Herbs ground in a mortar" className="mt-10 h-64 w-full rounded-2xl object-cover shadow-xl" />
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={IMG_OILS} alt="Medicated Ayurvedic oils" className="col-span-2 h-48 w-full rounded-2xl object-cover shadow-xl" />
            </div>
            <div className="anim-float absolute top-4 -left-4 rounded-2xl border border-brown/10 bg-paper px-4 py-3 shadow-xl">
              <LogoMark className="h-10 w-10" />
            </div>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-20">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="text-[0.68rem] font-bold tracking-[0.24em] text-gold uppercase">What we stand for</p>
          <h2 className="mt-3 font-display text-4xl font-semibold text-brown-deep sm:text-5xl">Four values, every patient</h2>
        </Reveal>
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {VALUES.map((v, i) => (
            <Reveal key={v.t} delay={i * 90}>
              <div className="card-lift h-full rounded-2xl border-t-4 border-gold bg-paper p-6 shadow-sm">
                <span className="font-display text-4xl font-bold text-gold/40">0{i + 1}</span>
                <h3 className="mt-3 font-display text-2xl font-semibold text-brown">{v.t}</h3>
                <p className="mt-2 text-sm leading-relaxed text-ink/70">{v.d}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="bg-cocoa py-20 text-cream">
        <div className="mx-auto max-w-5xl px-6">
          <Reveal className="text-center">
            <p className="text-[0.68rem] font-bold tracking-[0.24em] text-gold uppercase">Milestones</p>
            <h2 className="mt-3 font-display text-4xl font-semibold sm:text-5xl">The Balark timeline</h2>
          </Reveal>
          <ol className="relative mt-14 space-y-10 border-l-2 border-gold/30 pl-8">
            {TIMELINE.map((t, i) => (
              <Reveal key={t.year} delay={i * 80} as="li">
                <span className="absolute -left-[9px] mt-1.5 h-4 w-4 rounded-full border-2 border-cocoa bg-gold" />
                <p className="font-display text-2xl font-bold text-gold">{t.year}</p>
                <h3 className="mt-1 font-display text-xl font-semibold">{t.title}</h3>
                <p className="mt-1.5 max-w-2xl text-sm leading-relaxed text-cream/70">{t.text}</p>
              </Reveal>
            ))}
          </ol>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-20">
        <div className="grid items-center gap-10 rounded-3xl border border-brown/12 bg-paper p-10 lg:grid-cols-[1.2fr_0.8fr] lg:p-14">
          <Reveal>
            <h2 className="font-display text-3xl font-semibold text-brown-deep sm:text-4xl">
              “At Balark, we believe true healing begins from the root cause — not just temporary relief.”
            </h2>
            <p className="mt-4 text-ink/70">
              That single sentence shapes our therapy rooms, our pharmacy and now this website:
              book in minutes, arrive to a prepared doctor, and leave with a plan that treats the
              cause, not the symptom.
            </p>
            <div className="mt-7 flex flex-wrap gap-4">
              <Link href="/treatments" className="rounded-full bg-brown px-7 py-3.5 text-sm font-bold text-cream transition hover:-translate-y-0.5 hover:bg-brown-deep">
                Browse therapies
              </Link>
              <Link href="/contact" className="rounded-full border-2 border-brown/25 px-7 py-3.5 text-sm font-bold text-brown transition hover:-translate-y-0.5 hover:border-sage hover:text-sage-deep">
                Visit a branch
              </Link>
            </div>
          </Reveal>
          <Reveal delay={150} className="justify-self-center">
            <LogoMark className="h-44 w-44" />
          </Reveal>
        </div>
      </section>
    </>
  );
}
