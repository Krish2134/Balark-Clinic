import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { doctors, treatments } from "@/db/schema";
import BookingFlow from "@/components/BookingFlow";
import Reveal from "@/components/Reveal";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Book an Appointment | Balark Ayurveda and Panchakarma Clinic",
  description:
    "Choose your doctor, branch and time slot. Your doctor receives an instant email and WhatsApp alert with your booking details.",
};

export default async function Book({
  searchParams,
}: {
  searchParams: Promise<{ doctor?: string; treatment?: string }>;
}) {
  const sp = await searchParams;
  const [docs, treats] = await Promise.all([
    db.select().from(doctors).orderBy(asc(doctors.sortOrder)),
    db.select().from(treatments).where(eq(treatments.comingSoon, false)).orderBy(asc(treatments.sortOrder)),
  ]);

  return (
    <>
      <section className="border-b border-brown/10 bg-cream-deep/50 py-14">
        <div className="mx-auto max-w-7xl px-6">
          <Reveal>
            <p className="text-[0.68rem] font-bold tracking-[0.24em] text-gold uppercase">Advanced appointment system</p>
            <h1 className="mt-3 max-w-3xl font-display text-[clamp(2.4rem,5vw,3.8rem)] leading-[1.05] font-semibold text-brown-deep">
              <span className="line-mask"><span>Book your doctor,</span></span>
              <span className="line-mask" style={{ "--reveal-delay": "120ms" } as React.CSSProperties}>
                <span>your time, your branch.</span>
              </span>
            </h1>
            <p className="mt-4 max-w-2xl leading-relaxed text-ink/75">
              Three calm steps. Live slot availability, zero double-booking, and an instant
              email + WhatsApp alert to your doctor the moment you confirm.
            </p>
          </Reveal>
        </div>
      </section>
      <section className="mx-auto max-w-7xl px-6 py-14">
        <BookingFlow
          doctors={docs}
          treatments={treats}
          initialDoctor={sp.doctor}
          initialTreatment={sp.treatment}
        />
      </section>
    </>
  );
}
