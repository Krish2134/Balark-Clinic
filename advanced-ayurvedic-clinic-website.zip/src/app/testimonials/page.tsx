import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { testimonials } from "@/db/schema";
import Reveal from "@/components/Reveal";
import Stars from "@/components/Stars";
import TestimonialForm from "@/components/TestimonialForm";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Patient Testimonials | Balark Ayurveda and Panchakarma Clinic",
  description:
    "Real stories from patients treated for joint pain, spine disorders, migraine, skin and hair conditions at Balark Ayurveda, Gandhinagar & Visnagar.",
};

export default async function Testimonials() {
  const reviews = await db
    .select()
    .from(testimonials)
    .where(eq(testimonials.approved, true))
    .orderBy(desc(testimonials.createdAt));

  const avg = reviews.length ? (reviews.reduce((a, r) => a + r.rating, 0) / reviews.length).toFixed(1) : "5.0";

  return (
    <>
      <section className="border-b border-brown/10 bg-cream-deep/50 py-16">
        <div className="mx-auto max-w-7xl px-6 text-center">
          <Reveal>
            <p className="text-[0.68rem] font-bold tracking-[0.24em] text-gold uppercase">Patient stories</p>
            <h1 className="mt-3 font-display text-[clamp(2.4rem,5vw,4rem)] leading-[1.05] font-semibold text-brown-deep">
              <span className="line-mask"><span>35,000+ patients.</span></span>
              <span className="line-mask" style={{ "--reveal-delay": "120ms" } as React.CSSProperties}>
                <span>Thousands of quiet recoveries.</span>
              </span>
            </h1>
            <div className="mt-6 inline-flex items-center gap-3 rounded-full border border-brown/15 bg-paper px-6 py-3">
              <Stars rating={5} className="h-5 w-5" />
              <span className="font-display text-xl font-bold text-brown">{avg}</span>
              <span className="text-sm text-ink/60">average from {reviews.length} published reviews</span>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-16">
        <div className="columns-1 gap-6 md:columns-2 lg:columns-3 [&>*]:mb-6">
          {reviews.map((r, i) => (
            <Reveal key={r.id} delay={(i % 3) * 70}>
              <figure className="card-lift break-inside-avoid rounded-2xl border border-brown/12 bg-paper p-7">
                <div className="flex items-center justify-between">
                  <Stars rating={r.rating} />
                  <svg viewBox="0 0 24 24" className="h-7 w-7 fill-gold/25">
                    <path d="M10 7H6a3 3 0 0 0-3 3v7h7v-7H7c0-1.7 1.3-3 3-3V7zm11 0h-4a3 3 0 0 0-3 3v7h7v-7h-3c0-1.7 1.3-3 3-3V7z" />
                  </svg>
                </div>
                <blockquote className="mt-4 leading-relaxed text-ink/80">“{r.body}”</blockquote>
                <figcaption className="mt-5 flex items-center gap-3 border-t border-brown/10 pt-4">
                  <span className="flex h-10 w-10 items-center justify-center rounded-full bg-sage/15 font-display text-lg font-bold text-sage-deep">
                    {r.name.charAt(0)}
                  </span>
                  <span>
                    <span className="block font-display text-lg font-semibold text-brown">{r.name}</span>
                    <span className="block text-[0.7rem] tracking-wide text-ink/55">
                      {r.location} • {r.treatment}
                    </span>
                  </span>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="bg-cream-deep/60 py-16">
        <div className="mx-auto max-w-3xl px-6">
          <Reveal className="text-center">
            <h2 className="font-display text-3xl font-semibold text-brown-deep sm:text-4xl">Treated at Balark? Tell your story.</h2>
            <p className="mt-3 text-ink/70">Reviews are published after a quick moderation by the clinic team.</p>
          </Reveal>
          <Reveal delay={120} className="mt-8">
            <TestimonialForm />
          </Reveal>
        </div>
      </section>
    </>
  );
}
