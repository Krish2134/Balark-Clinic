import type { Metadata } from "next";
import { Cormorant_Garamond, Manrope } from "next/font/google";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import WhatsAppFloat from "@/components/WhatsAppFloat";
import ChatWidget from "@/components/ChatWidget";

const cormorant = Cormorant_Garamond({
  subsets: ["latin"],
  weight: ["500", "600", "700"],
  variable: "--font-cormorant",
});

const manrope = Manrope({
  subsets: ["latin"],
  variable: "--font-manrope",
});

export const metadata: Metadata = {
  title:
    "Balark Ayurveda and Panchakarma Clinic | Panchakarma, Joint & Spine Care in Gandhinagar & Visnagar",
  description:
    "Since 2008, Balark Ayurveda and Panchakarma Clinic offers classical Panchakarma, Shirodhara, Abhyanga, joint & spine care, hair and skin therapies in Gandhinagar and Visnagar, Gujarat. Book an appointment with Dr Chirag Vyas or Dhruva Vyas.",
  keywords: [
    "Ayurveda clinic Gandhinagar",
    "Panchakarma Visnagar",
    "Shirodhara",
    "Abhyanga",
    "Joint pain Ayurveda",
    "Balark Ayurveda",
  ],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${cormorant.variable} ${manrope.variable}`}>
      <body className="page-bg font-body text-ink">
        <div className="noise-overlay" aria-hidden="true" />
        <Header />
        <main>{children}</main>
        <Footer />
        <WhatsAppFloat />
        <ChatWidget />
      </body>
    </html>
  );
}
