"use client";

import { useCallback, useEffect, useState } from "react";

type Notif = { channel: string; recipient: string; status: string; detail?: string | null };
type Row = {
  id: number;
  code: string;
  patientName: string;
  phone: string;
  email: string | null;
  doctorName: string;
  location: string;
  date: string;
  timeSlot: string;
  reason: string;
  status: string;
  createdAt: string;
  notifications: Notif[];
};

export default function Admin() {
  const [token, setToken] = useState("");
  const [unlocked, setUnlocked] = useState(false);
  const [rows, setRows] = useState<Row[]>([]);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState<number | null>(null);

  const load = useCallback(async (t: string) => {
    const res = await fetch(`/api/appointments?token=${encodeURIComponent(t)}`);
    if (!res.ok) throw new Error("Invalid passcode");
    const data = await res.json();
    setRows((data.appointments as Row[]).reverse());
  }, []);

  async function unlock(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    try {
      await load(token);
      setUnlocked(true);
      sessionStorage.setItem("balark_admin", token);
    } catch {
      setError("Wrong passcode. Ask the clinic owner for the dashboard passcode.");
    }
  }

  useEffect(() => {
    const saved = sessionStorage.getItem("balark_admin");
    if (saved) {
      setToken(saved);
      load(saved).then(() => setUnlocked(true)).catch(() => sessionStorage.removeItem("balark_admin"));
    }
  }, [load]);

  async function setStatus(id: number, status: "confirmed" | "cancelled") {
    setBusy(id);
    await fetch(`/api/appointments/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token, status }),
    });
    await load(token);
    setBusy(null);
  }

  if (!unlocked) {
    return (
      <section className="mx-auto flex max-w-md flex-col px-6 py-24">
        <form onSubmit={unlock} className="rounded-3xl border border-brown/12 bg-paper p-9 text-center shadow-xl">
          <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-sage/12 text-sage-deep">
            <svg viewBox="0 0 24 24" className="h-7 w-7 fill-none stroke-current" strokeWidth="2">
              <rect x="4" y="10" width="16" height="10" rx="2.5" />
              <path d="M8 10V7a4 4 0 0 1 8 0v3" />
            </svg>
          </span>
          <h1 className="mt-5 font-display text-3xl font-semibold text-brown-deep">Doctor Dashboard</h1>
          <p className="mt-2 text-sm text-ink/65">
            View every appointment and the email / WhatsApp alerts sent to the doctors.
          </p>
          <input
            type="password"
            value={token}
            onChange={(e) => setToken(e.target.value)}
            placeholder="Dashboard passcode"
            className="field mt-6 text-center"
          />
          {error && <p className="mt-3 text-sm font-semibold text-flame">{error}</p>}
          <button type="submit" className="mt-4 w-full rounded-full bg-sage py-3.5 text-sm font-bold text-cream transition hover:bg-sage-deep">
            Unlock dashboard
          </button>
        </form>
      </section>
    );
  }

  const pending = rows.filter((r) => r.status === "pending").length;
  const confirmed = rows.filter((r) => r.status === "confirmed").length;

  return (
    <section className="mx-auto max-w-7xl px-6 py-14">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-[0.68rem] font-bold tracking-[0.24em] text-gold uppercase">Doctor dashboard</p>
          <h1 className="mt-2 font-display text-4xl font-semibold text-brown-deep">Appointments</h1>
        </div>
        <div className="flex gap-3 text-sm font-bold">
          <span className="rounded-full bg-gold/20 px-4 py-2 text-gold">{pending} pending</span>
          <span className="rounded-full bg-sage/15 px-4 py-2 text-sage-deep">{confirmed} confirmed</span>
          <button onClick={() => load(token)} className="rounded-full border border-brown/25 px-4 py-2 text-brown transition hover:border-sage hover:text-sage-deep">
            Refresh
          </button>
        </div>
      </div>

      <div className="mt-8 overflow-x-auto rounded-2xl border border-brown/12 bg-paper shadow">
        <table className="w-full min-w-[64rem] text-left text-sm">
          <thead className="bg-cocoa text-cream">
            <tr>
              {["Reference", "Patient", "Doctor", "Branch / When", "Reason", "Doctor alerts", "Status", "Actions"].map((h) => (
                <th key={h} className="px-4 py-3.5 text-[0.68rem] font-bold tracking-[0.14em] uppercase">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-brown/10">
            {rows.length === 0 && (
              <tr>
                <td colSpan={8} className="px-4 py-10 text-center text-ink/55">
                  No appointments yet. Bookings made on /book appear here instantly.
                </td>
              </tr>
            )}
            {rows.map((r) => (
              <tr key={r.id} className="align-top transition hover:bg-cream-deep/40">
                <td className="px-4 py-4 font-bold text-sage-deep">{r.code}</td>
                <td className="px-4 py-4">
                  <p className="font-semibold text-ink">{r.patientName}</p>
                  <p className="text-[0.72rem] text-ink/55">{r.phone}</p>
                </td>
                <td className="px-4 py-4">{r.doctorName}</td>
                <td className="px-4 py-4">
                  <p className="font-semibold">{r.location}</p>
                  <p className="text-[0.72rem] text-ink/55">{r.date} • {r.timeSlot}</p>
                </td>
                <td className="max-w-52 px-4 py-4 text-[0.8rem] text-ink/70">{r.reason}</td>
                <td className="px-4 py-4">
                  <div className="flex flex-col gap-1">
                    {r.notifications.slice(0, 4).map((n, i) => (
                      <span key={i} className={`rounded-full px-2.5 py-0.5 text-[0.6rem] font-extrabold tracking-wider uppercase ${n.status === "sent" ? "bg-sage/15 text-sage-deep" : n.status === "failed" ? "bg-flame/15 text-flame" : "bg-gold/20 text-gold"}`}>
                        {n.channel} · {n.status}
                      </span>
                    ))}
                  </div>
                </td>
                <td className="px-4 py-4">
                  <span className={`rounded-full px-3 py-1 text-[0.65rem] font-extrabold tracking-wider uppercase ${r.status === "confirmed" ? "bg-sage/15 text-sage-deep" : r.status === "cancelled" ? "bg-flame/15 text-flame" : "bg-gold/20 text-gold"}`}>
                    {r.status}
                  </span>
                </td>
                <td className="px-4 py-4">
                  <div className="flex gap-2">
                    {r.status !== "confirmed" && (
                      <button disabled={busy === r.id} onClick={() => setStatus(r.id, "confirmed")} className="rounded-full bg-sage px-3.5 py-1.5 text-[0.68rem] font-bold text-cream transition hover:bg-sage-deep disabled:opacity-50">
                        Confirm
                      </button>
                    )}
                    {r.status !== "cancelled" && (
                      <button disabled={busy === r.id} onClick={() => setStatus(r.id, "cancelled")} className="rounded-full border border-flame/50 px-3.5 py-1.5 text-[0.68rem] font-bold text-flame transition hover:bg-flame hover:text-cream disabled:opacity-50">
                        Cancel
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="mt-4 text-[0.75rem] text-ink/55">
        Alerts show as <strong>queued</strong> until email (RESEND_API_KEY) and WhatsApp Cloud API
        (WHATSAPP_CLOUD_TOKEN + WHATSAPP_PHONE_ID) keys are added to the server environment — then
        they deliver automatically and flip to <strong>sent</strong>.
      </p>
    </section>
  );
}
