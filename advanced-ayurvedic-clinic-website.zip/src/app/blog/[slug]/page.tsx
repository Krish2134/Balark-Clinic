import Link from "next/link";
import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { posts } from "@/db/schema";
import Reveal from "@/components/Reveal";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const [p] = await db.select().from(posts).where(eq(posts.slug, slug)).limit(1);
  return { title: p ? `${p.title} | Balark Ayurveda Journal` : "Article | Balark Ayurveda", description: p?.excerpt };
}

export default async function PostPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const [p] = await db.select().from(posts).where(eq(posts.slug, slug)).limit(1);
  if (!p) notFound();

  return (
    <article className="mx-auto max-w-3xl px-6 py-16">
      <Reveal>
        <nav className="flex items-center gap-2 text-[0.68rem] font-bold tracking-wider text-ink/50 uppercase">
          <Link href="/" className="hover:text-gold">Home</Link> /
          <Link href="/blog" className="hover:text-gold">Journal</Link> /
          <span className="text-gold">{p.tag}</span>
        </nav>
        <h1 className="mt-5 font-display text-[clamp(2.2rem,5vw,3.6rem)] leading-[1.08] font-semibold text-brown-deep">{p.title}</h1>
        <p className="mt-4 text-[0.78rem] font-bold tracking-wide text-ink/55">
          {p.author} • {p.publishedAt.toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" })}
        </p>
      </Reveal>
      <Reveal delay={120}>
        <div className="mt-8 space-y-5 text-[1.02rem] leading-relaxed text-ink/80">
          {p.content.split("\n\n").map((para, i) => (
            <p key={i}>{para}</p>
          ))}
        </div>
      </Reveal>
      <Reveal delay={180}>
        <div className="mt-12 rounded-2xl border border-gold/40 bg-gold/10 p-7 text-center">
          <p className="font-display text-2xl font-semibold text-brown-deep">Want this guidance personalised?</p>
          <p className="mt-2 text-sm text-ink/70">Book a consultation at Gandhinagar or Visnagar — or online.</p>
          <div className="mt-5 flex flex-wrap justify-center gap-3">
            <Link href="/book" className="rounded-full bg-sage px-7 py-3 text-sm font-bold text-cream transition hover:bg-sage-deep">Book Appointment</Link>
            <Link href="/blog" className="rounded-full border-2 border-brown/25 px-7 py-3 text-sm font-bold text-brown transition hover:border-sage hover:text-sage-deep">More articles</Link>
          </div>
        </div>
      </Reveal>
    </article>
  );
}
