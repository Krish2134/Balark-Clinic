import Link from "next/link";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { posts } from "@/db/schema";
import Reveal from "@/components/Reveal";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Ayurveda Journal | Balark Ayurveda Blog",
  description:
    "Practical Ayurveda wisdom from the physicians of Balark Ayurveda and Panchakarma Clinic — Panchakarma, seasonal care, hair & skin rituals.",
};

export default async function Blog() {
  const all = await db.select().from(posts).orderBy(desc(posts.publishedAt));
  const [first, ...rest] = all;

  return (
    <>
      <section className="border-b border-brown/10 bg-cream-deep/50 py-16">
        <div className="mx-auto max-w-7xl px-6">
          <Reveal>
            <p className="text-[0.68rem] font-bold tracking-[0.24em] text-gold uppercase">The Ayurveda journal</p>
            <h1 className="mt-3 max-w-3xl font-display text-[clamp(2.4rem,5vw,4rem)] leading-[1.05] font-semibold text-brown-deep">
              <span className="line-mask"><span>Wisdom from our therapy rooms,</span></span>
              <span className="line-mask" style={{ "--reveal-delay": "120ms" } as React.CSSProperties}>
                <span>written for your home.</span>
              </span>
            </h1>
          </Reveal>
          <Reveal delay={150}>
            <p className="mt-6 inline-flex items-center gap-2.5 rounded-full border border-sage/40 bg-sage/10 px-5 py-2.5 text-[0.72rem] font-bold tracking-wide text-sage-deep">
              <svg viewBox="0 0 24 24" className="h-4 w-4 fill-none stroke-current" strokeWidth="2">
                <path d="M12 3v18M3 12h18" strokeLinecap="round" />
              </svg>
              WordPress blog & WooCommerce store integration is on the roadmap — this journal syncs with it.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-16">
        {first && (
          <Reveal>
            <Link href={`/blog/${first.slug}`} className="card-lift grid overflow-hidden rounded-3xl border border-brown/12 bg-paper lg:grid-cols-2">
              <div className="relative bg-sage-deep p-10 text-cream lg:p-14">
                <p className="text-[0.66rem] font-bold tracking-[0.2em] text-gold uppercase">{first.tag}</p>
                <h2 className="mt-4 font-display text-4xl leading-tight font-semibold">{first.title}</h2>
                <p className="mt-4 text-cream/80">{first.excerpt}</p>
                <p className="mt-8 text-[0.72rem] font-bold tracking-wide text-cream/60">
                  {first.author} • {first.publishedAt.toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" })}
                </p>
                <span className="mt-6 inline-block rounded-full bg-cream px-6 py-3 text-[0.75rem] font-bold text-sage-deep">Read article →</span>
              </div>
              <div className="relative min-h-64 overflow-hidden">
                <svg viewBox="0 0 400 300" className="absolute inset-0 h-full w-full" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
                  <rect width="400" height="300" fill="#F3EACC" />
                  <path d="M120 40c60 30 80 90 50 150-60-25-85-95-50-150z" fill="#2E8B62" opacity="0.85" />
                  <path d="M250 70c-45 30-60 85-32 130 50-20 70-85 32-130z" fill="#45A578" opacity="0.8" />
                  <circle cx="200" cy="210" r="46" fill="#C9973B" opacity="0.9" />
                  <path d="M200 186c11 10 14 26 6 40-13-6-19-26-6-40z" fill="#3B241F" />
                  <path d="M60 250h280c0 0-40 40-140 40S60 250 60 250z" fill="#6B4444" />
                </svg>
              </div>
            </Link>
          </Reveal>
        )}

        <div className="mt-10 grid gap-7 md:grid-cols-2 lg:grid-cols-3">
          {rest.map((p, i) => (
            <Reveal key={p.slug} delay={(i % 3) * 80}>
              <Link href={`/blog/${p.slug}`} className="card-lift flex h-full flex-col rounded-2xl border border-brown/12 bg-paper p-7">
                <p className="text-[0.62rem] font-bold tracking-[0.18em] text-gold uppercase">{p.tag}</p>
                <h3 className="mt-3 font-display text-2xl leading-snug font-semibold text-brown">{p.title}</h3>
                <p className="mt-3 flex-1 text-sm leading-relaxed text-ink/70">{p.excerpt}</p>
                <p className="mt-5 border-t border-brown/10 pt-4 text-[0.7rem] font-bold tracking-wide text-sage-deep">
                  Read article →
                </p>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>
    </>
  );
}
