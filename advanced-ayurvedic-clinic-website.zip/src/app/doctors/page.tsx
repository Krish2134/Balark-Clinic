import Link from "next/link";
import { asc } from "drizzle-orm";
import { db } from "@/db";
import { doctors } from "@/db/schema";
import Reveal from "@/components/Reveal";
import { SITE, waLink } from "@/lib/site";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Our Doctors | Balark Ayurveda and Panchakarma Clinic",
  description:
    "Dr Chirag Vyas (B.A.M.S, P.G. C.P.K, Medical Astrology) and Dhruva Vyas (Ayurveda Pharmacist & Female Panchakarma Therapy Expert) — 17+ years, 35,000+ patients.",
};

export default async function Doctors() {
  const docs = await db.select().from(doctors).orderBy(asc(doctors.sortOrder));

  return (
    <>
      <section className="border-b border-brown/10 bg-cream-deep/50 py-16">
        <div className="mx-auto max-w-7xl px-6 text-center">
          <Reveal>
            <p className="text-[0.68rem] font-bold tracking-[0.24em] text-gold uppercase">The healers</p>
            <h1 className="mt-3 font-display text-[clamp(2.4rem,5vw,4rem)] leading-[1.05] font-semibold text-brown-deep">
              <span className="line-mask"><span>Hands you can trust,</span></span>
              <span className="line-mask" style={{ "--reveal-delay": "120ms" } as React.CSSProperties}>
                <span>knowledge you can feel.</span>
              </span>
            </h1>
            <p className="mx-auto mt-5 max-w-2xl leading-relaxed text-ink/75">
              Between them: 17+ years of practice, 35,000+ patients treated successfully, an
              in-house pharmacy and a female Panchakarma therapy expertise rare in Gujarat.
              Offline and online consultation available.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-7xl space-y-16 px-6 py-20">
        {docs.map((d, i) => (
          <Reveal key={d.slug}>
            <article
              className={`grid items-stretch gap-0 overflow-hidden rounded-3xl border border-brown/12 bg-paper shadow-[0_30px_60px_-30px_rgba(59,36,31,0.45)] lg:grid-cols-[0.9fr_1.1fr] ${
                i % 2 === 1 ? "lg:[&>div:first-child]:order-2" : ""
              }`}
            >
              <div className="relative min-h-[26rem] overflow-hidden bg-brown-deep">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={d.image}
                  alt={`${d.name} — ${d.role}`}
                  className="absolute inset-0 h-full w-full object-cover object-top transition-transform duration-[1400ms] hover:scale-105"
                />
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-cocoa/90 to-transparent p-6 pt-16">
                  <p className="inline-flex items-center gap-2 rounded-full bg-gold px-3.5 py-1.5 text-[0.62rem] font-extrabold tracking-[0.16em] text-cocoa uppercase">
                    {d.experienceYears}+ years • {d.patientsTreated} patients
                  </p>
                </div>
              </div>

              <div className="flex flex-col justify-center p-8 lg:p-12">
                <p className="text-[0.66rem] font-bold tracking-[0.22em] text-gold uppercase">{d.role}</p>
                <h2 className="mt-3 font-display text-4xl font-semibold text-brown-deep sm:text-5xl">{d.name}</h2>
                <p className="mt-2 font-display text-xl text-sage-deep italic">({d.qualifications})</p>
                <p className="mt-5 leading-relaxed text-ink/75">{d.bio}</p>

                <ul className="mt-6 grid gap-2.5 sm:grid-cols-2">
                  {d.specialties.map((s) => (
                    <li key={s} className="flex items-start gap-2.5 rounded-xl bg-cream-deep/60 p-3 text-[0.82rem] leading-snug text-ink/80">
                      <svg viewBox="0 0 24 24" className="mt-0.5 h-4 w-4 shrink-0 fill-none stroke-sage" strokeWidth="2.4">
                        <path d="M5 13l4 4L19 7" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                      {s}
                    </li>
                  ))}
                </ul>

                <div className="mt-8 flex flex-wrap items-center gap-3">
                  <Link href={`/book?doctor=${d.slug}`} className="rounded-full bg-sage px-6 py-3 text-[0.78rem] font-bold tracking-wide text-cream transition hover:-translate-y-0.5 hover:bg-sage-deep">
                    Book Appointment
                  </Link>
                  <a href={waLink(d.whatsapp, `Namaste ${d.name} 🙏 I would like to consult you at Balark Clinic.`)} target="_blank" rel="noreferrer" className="rounded-full bg-[#25D366] px-6 py-3 text-[0.78rem] font-bold tracking-wide text-white transition hover:-translate-y-0.5 hover:brightness-95">
                    WhatsApp
                  </a>
                  <a href={`tel:${d.whatsapp}`} className="rounded-full border-2 border-brown/25 px-6 py-3 text-[0.78rem] font-bold tracking-wide text-brown transition hover:-translate-y-0.5 hover:border-gold hover:text-gold">
                    {d.phone}
                  </a>
                </div>
              </div>
            </article>
          </Reveal>
        ))}
      </section>

      <section className="bg-cocoa py-16 text-cream">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <Reveal>
            <h2 className="font-display text-3xl font-semibold sm:text-4xl">Offline and online consultation</h2>
            <p className="mx-auto mt-4 max-w-2xl text-cream/75">
              Visit us in Gandhinagar or Visnagar, or consult from anywhere over call and video.
              When you book online, your chosen doctor receives an instant email and WhatsApp
              alert with your slot and reason for visit.
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-4">
              <Link href="/book" className="rounded-full bg-sage px-8 py-4 text-sm font-bold text-cream transition hover:-translate-y-1 hover:bg-sage-deep">
                Book an Appointment
              </Link>
              <a href={SITE.phones[0].href} className="rounded-full border-2 border-cream/40 px-8 py-4 text-sm font-bold transition hover:-translate-y-1 hover:border-cream">
                Call {SITE.phones[0].label}
              </a>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
