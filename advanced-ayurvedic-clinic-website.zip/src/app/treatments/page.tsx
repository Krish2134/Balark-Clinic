import Link from "next/link";
import { asc, eq, ne } from "drizzle-orm";
import { db } from "@/db";
import { treatments } from "@/db/schema";
import Reveal from "@/components/Reveal";
import TreatmentCard from "@/components/TreatmentCard";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Treatments & Panchakarma Therapies | Balark Ayurveda",
  description:
    "Shirodhara, Abhyanga, Panchakarma Detox, Kati Basti, Nasya, Takradhara, hair & skin care and more at Balark Ayurveda and Panchakarma Clinic, Gandhinagar & Visnagar.",
};

export default async function Treatments({
  searchParams,
}: {
  searchParams: Promise<{ cat?: string }>;
}) {
  const { cat } = await searchParams;
  const all = await db.select().from(treatments).orderBy(asc(treatments.sortOrder));
  const live = all.filter((t) => !t.comingSoon);
  const soon = all.filter((t) => t.comingSoon);
  const categories = Array.from(new Set(live.map((t) => t.category)));
  const shown = cat && cat !== "All" ? live.filter((t) => t.category === cat) : live;

  return (
    <>
      <section className="border-b border-brown/10 bg-cream-deep/50 py-16">
        <div className="mx-auto max-w-7xl px-6">
          <Reveal>
            <p className="text-[0.68rem] font-bold tracking-[0.24em] text-gold uppercase">Therapy menu</p>
            <h1 className="mt-3 max-w-3xl font-display text-[clamp(2.4rem,5vw,4rem)] leading-[1.05] font-semibold text-brown-deep">
              <span className="line-mask"><span>Treatments & Panchakarma</span></span>
              <span className="line-mask" style={{ "--reveal-delay": "120ms" } as React.CSSProperties}>
                <span>therapies at Balark</span>
              </span>
            </h1>
            <p className="mt-5 max-w-2xl leading-relaxed text-ink/75">
              Every therapy below is performed with in-house prepared, certified organic oils.
              We list names and benefits — never fixed prices — because your protocol is decided
              after consultation. Online payments arrive soon; until then booking is free.
            </p>
          </Reveal>
          <Reveal delay={150}>
            <div className="mt-8 flex flex-wrap gap-2.5">
              {["All", ...categories].map((c) => (
                <Link
                  key={c}
                  href={c === "All" ? "/treatments" : `/treatments?cat=${encodeURIComponent(c)}`}
                  className={`rounded-full px-4.5 py-2 text-[0.72rem] font-bold tracking-wide transition ${
                    (cat ?? "All") === c
                      ? "bg-sage text-cream shadow"
                      : "border border-brown/20 bg-paper text-brown hover:border-sage hover:text-sage-deep"
                  }`}
                >
                  {c}
                </Link>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-16">
        <div className="grid gap-7 sm:grid-cols-2 lg:grid-cols-3">
          {shown.map((t, i) => (
            <Reveal key={t.slug} delay={(i % 3) * 80}>
              <TreatmentCard t={t} />
            </Reveal>
          ))}
        </div>
      </section>

      <section className="bg-cream-deep/60 py-16">
        <div className="mx-auto max-w-7xl px-6">
          <Reveal className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="text-[0.68rem] font-bold tracking-[0.24em] text-gold uppercase">In preparation</p>
              <h2 className="mt-2 font-display text-3xl font-semibold text-brown-deep sm:text-4xl">
                Therapies we are adding soon
              </h2>
              <p className="mt-3 max-w-2xl text-ink/70">
                Our menu grows according to the patients we serve. These classical procedures are
                being standardised in our therapy rooms right now.
              </p>
            </div>
            <Link href="/contact" className="rounded-full border-2 border-sage/50 px-6 py-3 text-sm font-bold text-sage-deep transition hover:bg-sage hover:text-cream">
              Request a therapy
            </Link>
          </Reveal>
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {soon.map((t, i) => (
              <Reveal key={t.slug} delay={i * 80}>
                <div className="relative flex h-full min-h-40 flex-col justify-between rounded-2xl border-2 border-dashed border-sage/50 bg-paper/70 p-6">
                  <span className="absolute -top-3 right-4 rotate-3 rounded-full bg-gold px-3 py-1 text-[0.58rem] font-extrabold tracking-[0.16em] text-cocoa uppercase shadow">
                    Adding soon
                  </span>
                  <div>
                    <p className="text-[0.6rem] font-bold tracking-[0.18em] text-sage-deep uppercase">{t.category}</p>
                    <h3 className="mt-2 font-display text-xl font-semibold text-brown">{t.name}</h3>
                  </div>
                  <p className="mt-3 text-[0.82rem] text-ink/65">{t.tagline}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-4xl px-6 py-16 text-center">
        <Reveal>
          <h2 className="font-display text-3xl font-semibold text-brown-deep sm:text-4xl">
            Not sure which therapy fits your condition?
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-ink/70">
            Describe your complaint to our AI assistant, message us on WhatsApp, or book a
            consultation — the doctor will design the protocol for you.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <Link href="/book" className="rounded-full bg-sage px-8 py-4 text-sm font-bold text-cream transition hover:-translate-y-0.5 hover:bg-sage-deep">
              Book an Appointment
            </Link>
            <Link href="/doctors" className="rounded-full border-2 border-brown/25 px-8 py-4 text-sm font-bold text-brown transition hover:-translate-y-0.5 hover:border-gold hover:text-gold">
              Choose your doctor
            </Link>
          </div>
        </Reveal>
      </section>
    </>
  );
}
