import Link from "next/link";
import { notFound } from "next/navigation";
import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { treatments } from "@/db/schema";
import Reveal from "@/components/Reveal";
import TreatmentCard from "@/components/TreatmentCard";
import { waLink, SITE } from "@/lib/site";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const t = await db.select().from(treatments).where(eq(treatments.slug, slug)).limit(1);
  return {
    title: t[0] ? `${t[0].name} | Balark Ayurveda` : "Treatment | Balark Ayurveda",
    description: t[0]?.tagline,
  };
}

export default async function TreatmentDetail({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const [t] = await db.select().from(treatments).where(eq(treatments.slug, slug)).limit(1);
  if (!t) notFound();

  const others = await db
    .select()
    .from(treatments)
    .where(eq(treatments.featured, true))
    .orderBy(asc(treatments.sortOrder))
    .limit(3);
  const related = others.filter((o) => o.slug !== t.slug).slice(0, 3);

  return (
    <>
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={t.image} alt="" aria-hidden="true" className="anim-kenburns h-full w-full object-cover" />
          <div className="absolute inset-0 bg-cocoa/78" />
        </div>
        <div className="relative mx-auto max-w-7xl px-6 py-24 lg:py-32">
          <Reveal>
            <nav className="flex items-center gap-2 text-[0.7rem] font-bold tracking-wider text-cream/60 uppercase">
              <Link href="/" className="hover:text-gold">Home</Link> /
              <Link href="/treatments" className="hover:text-gold">Treatments</Link> /
              <span className="text-gold">{t.name}</span>
            </nav>
            <p className="mt-6 inline-block rounded-full bg-gold/20 px-4 py-1.5 text-[0.66rem] font-bold tracking-[0.2em] text-gold uppercase">
              {t.category}
            </p>
            <h1 className="mt-4 max-w-3xl font-display text-[clamp(2.6rem,6vw,4.6rem)] leading-[1.03] font-semibold text-cream">
              {t.name}
            </h1>
            <p className="mt-5 max-w-2xl text-lg leading-relaxed text-cream/80">{t.tagline}</p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link href={`/book?treatment=${t.slug}`} className="rounded-full bg-sage px-8 py-4 text-sm font-bold text-cream shadow-xl transition hover:-translate-y-1 hover:bg-sage-deep">
                Book Appointment
              </Link>
              <a href={waLink(SITE.primaryWhatsapp, `Namaste 🙏 I would like to know more about ${t.name} at Balark Clinic.`)} target="_blank" rel="noreferrer" className="rounded-full border-2 border-cream/40 px-8 py-4 text-sm font-bold text-cream transition hover:-translate-y-1 hover:border-[#25D366] hover:text-[#25D366]">
                Ask on WhatsApp
              </a>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-20">
        <div className="grid gap-14 lg:grid-cols-[0.85fr_1.15fr]">
          {/* sticky facts column */}
          <div className="lg:sticky lg:top-32 lg:self-start">
            <Reveal>
              <div className="overflow-hidden rounded-2xl border border-brown/12 bg-paper shadow-lg">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={t.image} alt={t.name} className="h-56 w-full object-cover" />
                <dl className="grid grid-cols-2 divide-x divide-brown/10 border-t border-brown/10 text-center">
                  <div className="p-5">
                    <dt className="text-[0.62rem] font-bold tracking-[0.18em] text-ink/50 uppercase">Duration</dt>
                    <dd className="mt-1.5 font-display text-xl font-semibold text-brown">{t.duration}</dd>
                  </div>
                  <div className="p-5">
                    <dt className="text-[0.62rem] font-bold tracking-[0.18em] text-ink/50 uppercase">Category</dt>
                    <dd className="mt-1.5 font-display text-xl font-semibold text-brown">{t.category}</dd>
                  </div>
                </dl>
                <div className="border-t border-brown/10 p-5">
                  <p className="text-[0.62rem] font-bold tracking-[0.18em] text-ink/50 uppercase">Fees</p>
                  <p className="mt-1.5 text-sm text-ink/70">
                    Decided after consultation • <span className="font-bold text-gold">payment gateway coming soon</span>
                  </p>
                  <Link href={`/book?treatment=${t.slug}`} className="mt-4 block rounded-full bg-sage py-3 text-center text-[0.78rem] font-bold tracking-wide text-cream transition hover:bg-sage-deep">
                    Book Appointment
                  </Link>
                </div>
              </div>
            </Reveal>
          </div>

          <div>
            <Reveal>
              <h2 className="font-display text-3xl font-semibold text-brown-deep sm:text-4xl">About this therapy</h2>
              <p className="mt-5 leading-relaxed whitespace-pre-line text-ink/78">{t.description}</p>
            </Reveal>

            <Reveal delay={100}>
              <h3 className="mt-12 font-display text-2xl font-semibold text-brown-deep">Key benefits</h3>
              <ul className="mt-5 grid gap-3 sm:grid-cols-2">
                {t.benefits.map((b) => (
                  <li key={b} className="flex items-start gap-3 rounded-xl border border-brown/12 bg-paper p-4 text-sm text-ink/75">
                    <svg viewBox="0 0 24 24" className="mt-0.5 h-4.5 w-4.5 shrink-0 fill-none stroke-sage" strokeWidth="2.4">
                      <path d="M5 13l4 4L19 7" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    {b}
                  </li>
                ))}
              </ul>
            </Reveal>

            <Reveal delay={160}>
              <h3 className="mt-12 font-display text-2xl font-semibold text-brown-deep">What a session looks like</h3>
              <ol className="mt-6 space-y-5">
                {t.steps.map((s, i) => (
                  <li key={s} className="flex gap-4">
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-sage/15 font-display text-lg font-bold text-sage-deep">
                      {i + 1}
                    </span>
                    <p className="pt-1.5 text-sm leading-relaxed text-ink/75">{s}</p>
                  </li>
                ))}
              </ol>
            </Reveal>

            <Reveal delay={220}>
              <div className="mt-12 rounded-2xl border border-gold/40 bg-gold/10 p-6">
                <p className="font-display text-xl font-semibold text-brown-deep">
                  Ready to begin? Your doctor is alerted the moment you book.
                </p>
                <div className="mt-4 flex flex-wrap gap-3">
                  <Link href={`/book?treatment=${t.slug}`} className="rounded-full bg-sage px-6 py-3 text-[0.78rem] font-bold text-cream transition hover:bg-sage-deep">
                    Book Appointment
                  </Link>
                  <Link href="/treatments" className="rounded-full border-2 border-brown/25 px-6 py-3 text-[0.78rem] font-bold text-brown transition hover:border-sage hover:text-sage-deep">
                    All treatments
                  </Link>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {related.length > 0 && (
        <section className="bg-cream-deep/60 py-16">
          <div className="mx-auto max-w-7xl px-6">
            <Reveal>
              <h2 className="font-display text-3xl font-semibold text-brown-deep">Other signature therapies</h2>
            </Reveal>
            <div className="mt-8 grid gap-7 sm:grid-cols-2 lg:grid-cols-3">
              {related.map((r, i) => (
                <Reveal key={r.slug} delay={i * 90}>
                  <TreatmentCard t={r} />
                </Reveal>
              ))}
            </div>
          </div>
        </section>
      )}
    </>
  );
}
