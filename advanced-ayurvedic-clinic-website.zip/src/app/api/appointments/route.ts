import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { appointments, doctors, notifications } from "@/db/schema";
import { sendEmail, sendWhatsApp } from "@/lib/notify";
import { SITE } from "@/lib/site";

export const dynamic = "force-dynamic";

/** GET /api/appointments
 *  - ?doctor=slug&date=YYYY-MM-DD  → { bookedSlots } (public, for the wizard)
 *  - ?token=ADMIN_PASSCODE         → full list with doctor + notifications (dashboard)
 */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const doctorSlug = url.searchParams.get("doctor");
  const date = url.searchParams.get("date");
  const token = url.searchParams.get("token");

  if (token) {
    const pass = process.env.ADMIN_PASSCODE ?? "balark-admin-2026";
    if (token !== pass) return NextResponse.json({ error: "Invalid passcode" }, { status: 401 });
    const rows = await db
      .select({
        appointment: appointments,
        doctorName: doctors.name,
        doctorPhone: doctors.phone,
        doctorEmail: doctors.email,
      })
      .from(appointments)
      .innerJoin(doctors, eq(appointments.doctorId, doctors.id))
      .orderBy(appointments.createdAt);
    const notifs = await db.select().from(notifications);
    const byAppt = new Map<number, typeof notifs>();
    notifs.forEach((n) => {
      const list = byAppt.get(n.appointmentId) ?? [];
      list.push(n);
      byAppt.set(n.appointmentId, list);
    });
    return NextResponse.json({
      appointments: rows.map((r) => ({ ...r.appointment, doctorName: r.doctorName, notifications: byAppt.get(r.appointment.id) ?? [] })),
    });
  }

  if (doctorSlug && date) {
    const [doc] = await db.select().from(doctors).where(eq(doctors.slug, doctorSlug)).limit(1);
    if (!doc) return NextResponse.json({ bookedSlots: [] });
    const existing = await db
      .select({ timeSlot: appointments.timeSlot })
      .from(appointments)
      .where(and(eq(appointments.doctorId, doc.id), eq(appointments.date, date)));
    const cancelledFree = new Set(
      (
        await db
          .select({ timeSlot: appointments.timeSlot })
          .from(appointments)
          .where(and(eq(appointments.doctorId, doc.id), eq(appointments.date, date), eq(appointments.status, "cancelled")))
      ).map((r) => r.timeSlot),
    );
    return NextResponse.json({
      bookedSlots: existing.filter((e) => !cancelledFree.has(e.timeSlot)).map((e) => e.timeSlot),
    });
  }

  return NextResponse.json({ error: "Missing query" }, { status: 400 });
}

/** POST /api/appointments — create booking + notify doctor by email & WhatsApp */
export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { doctorSlug, location, date, timeSlot, patientName, phone, email, treatmentSlug, reason } = body as Record<string, string | null>;

    if (!doctorSlug || !location || !date || !timeSlot || !patientName || !phone || !reason) {
      return NextResponse.json({ error: "Please fill all required fields." }, { status: 400 });
    }

    const [doc] = await db.select().from(doctors).where(eq(doctors.slug, String(doctorSlug))).limit(1);
    if (!doc) return NextResponse.json({ error: "Doctor not found." }, { status: 404 });

    // double-booking guard
    const clash = await db
      .select()
      .from(appointments)
      .where(and(eq(appointments.doctorId, doc.id), eq(appointments.date, String(date)), eq(appointments.timeSlot, String(timeSlot))));
    if (clash.some((c) => c.status !== "cancelled")) {
      return NextResponse.json({ error: "That slot was just taken. Please pick another time." }, { status: 409 });
    }

    const now = new Date();
    const code = `BLK-${now.getFullYear().toString().slice(2)}${String(now.getMonth() + 1).padStart(2, "0")}-${Math.floor(1000 + Math.random() * 9000)}`;

    const [appt] = await db
      .insert(appointments)
      .values({
        code,
        patientName: String(patientName),
        phone: String(phone),
        email: email ? String(email) : null,
        doctorId: doc.id,
        location: String(location),
        date: String(date),
        timeSlot: String(timeSlot),
        treatmentSlug: treatmentSlug ? String(treatmentSlug) : null,
        reason: String(reason),
      })
      .returning();

    const prettyDate = new Date(`${date}T00:00:00`).toLocaleDateString("en-IN", {
      weekday: "short",
      day: "numeric",
      month: "short",
      year: "numeric",
    });

    const emailBody = [
      `New appointment request ${code}`,
      ``,
      `Patient: ${patientName} (${phone})${email ? ` / ${email}` : ""}`,
      `Doctor: ${doc.name}`,
      `Branch: ${location}`,
      `When: ${prettyDate} at ${timeSlot}`,
      `Reason: ${reason}`,
      treatmentSlug ? `Preferred therapy: ${treatmentSlug}` : `Preferred therapy: doctor to advise`,
      ``,
      `Confirm or reschedule from the doctor dashboard: /admin`,
    ].join("\n");

    const waBody = `🌿 NEW APPOINTMENT ${code}\nPatient: ${patientName}\nPhone: ${phone}\nBranch: ${location}\nWhen: ${prettyDate}, ${timeSlot}\nReason: ${reason}\n— Balark website booking`;

    const [emailRes, waRes] = await Promise.all([
      sendEmail(doc.email, `New appointment ${code} — ${patientName} (${timeSlot})`, emailBody),
      sendWhatsApp(doc.whatsapp, waBody),
    ]);

    const created = await db
      .insert(notifications)
      .values([
        { appointmentId: appt.id, channel: "email", recipient: doc.email, status: emailRes.status, detail: emailRes.detail },
        { appointmentId: appt.id, channel: "whatsapp", recipient: `+${doc.whatsapp}`, status: waRes.status, detail: waRes.detail },
      ])
      .returning();

    return NextResponse.json({
      code: appt.code,
      doctorName: doc.name,
      location: appt.location,
      date: appt.date,
      timeSlot: appt.timeSlot,
      notifications: created.map((n) => ({ channel: n.channel, recipient: n.recipient, status: n.status })),
      whatsappLink: `https://wa.me/${SITE.primaryWhatsapp}?text=${encodeURIComponent(
        `Namaste 🙏 I just booked appointment ${code} with ${doc.name} on ${prettyDate} at ${timeSlot} (${location}). Please confirm. — ${patientName}`,
      )}`,
    });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Server error while booking." },
      { status: 500 },
    );
  }
}
