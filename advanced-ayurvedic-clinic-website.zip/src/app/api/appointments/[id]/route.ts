import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { appointments, doctors, notifications } from "@/db/schema";
import { sendEmail, sendWhatsApp } from "@/lib/notify";

export const dynamic = "force-dynamic";

/** PATCH /api/appointments/:id  { token, status: 'confirmed' | 'cancelled' } */
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = await req.json().catch(() => ({}));
  const pass = process.env.ADMIN_PASSCODE ?? "balark-admin-2026";
  if (body.token !== pass) return NextResponse.json({ error: "Invalid passcode" }, { status: 401 });
  const status = body.status === "confirmed" ? "confirmed" : body.status === "cancelled" ? "cancelled" : null;
  if (!status) return NextResponse.json({ error: "Bad status" }, { status: 400 });

  const [appt] = await db.update(appointments).set({ status }).where(eq(appointments.id, Number(id))).returning();
  if (!appt) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const [doc] = await db.select().from(doctors).where(eq(doctors.id, appt.doctorId)).limit(1);

  // notify patient side + keep doctor log
  const msg =
    status === "confirmed"
      ? `✅ CONFIRMED ${appt.code}: ${appt.patientName}, ${appt.date} at ${appt.timeSlot}, ${appt.location}. See you soon! — Balark Ayurveda`
      : `❌ CANCELLED ${appt.code}: ${appt.patientName}, ${appt.date} at ${appt.timeSlot}. — Balark Ayurveda`;

  const [waRes, emailRes] = await Promise.all([
    sendWhatsApp(appt.phone, msg),
    appt.email
      ? sendEmail(appt.email, `Appointment ${appt.code} ${status}`, msg)
      : Promise.resolve({ status: "queued" as const, detail: "No patient email provided" }),
  ]);

  await db.insert(notifications).values([
    { appointmentId: appt.id, channel: "whatsapp", recipient: appt.phone, status: waRes.status, detail: `Patient alert: ${status}` },
    { appointmentId: appt.id, channel: "email", recipient: appt.email ?? doc.email, status: emailRes.status, detail: `Status update: ${status}` },
  ]);

  return NextResponse.json({ ok: true, status });
}
