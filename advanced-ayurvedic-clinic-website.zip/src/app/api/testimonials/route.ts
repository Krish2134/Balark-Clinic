import { NextResponse } from "next/server";
import { db } from "@/db";
import { testimonials } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const b = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const name = String(b.name ?? "").trim();
  const location = String(b.location ?? "").trim();
  const body = String(b.body ?? "").trim();
  const rating = Math.min(5, Math.max(1, Number(b.rating) || 5));
  const treatment = String(b.treatment ?? "General Consultation");
  if (name.length < 2 || location.length < 2 || body.length < 10) {
    return NextResponse.json({ error: "Please complete all fields." }, { status: 400 });
  }
  await db.insert(testimonials).values({ name, location, body, rating, treatment, approved: false });
  return NextResponse.json({ ok: true, moderated: true });
}
