import { NextResponse } from "next/server";
import { asc } from "drizzle-orm";
import { db } from "@/db";
import { doctors, treatments } from "@/db/schema";
import { LOCATIONS, SITE } from "@/lib/site";

export const dynamic = "force-dynamic";

const CLINIC_FACTS = `Clinic: ${SITE.name}, since ${SITE.since}. Branches: Gandhinagar (Kudasan) and Visnagar, Gujarat.
Hours: Mon–Sat 9:00 AM–1:00 PM and 4:00 PM–8:00 PM; Sunday by appointment.
Doctors: Dr Chirag Vyas (B.A.M.S, P.G. C.P.K, Medical Astrology; 17+ years; 35,000+ patients; joint & spine care, Panchakarma, medical astrology) and Dhruva Vyas (Ayurveda pharmacist, female Panchakarma therapy expert; Balark hair oils, Dhruva herbal beauty/skin/hair products).
Treatments: Shirodhara, Abhyanga, Panchakarma Detox, Ayurvedic Facial, Nasya, Takradhara, Kati Basti, Janu Basti, Navarakizhi, Podikizhi, Udvartana, Dhruva Hair Care, Vaman & Virechan Karma, herbal consultation. Coming soon: Agnikarma, Ksharasutra, Leech therapy, Pizhichil.
Pricing: no fixed prices are published; every protocol is personalised after consultation. Online payment gateway is coming soon; booking is free and payment happens at the clinic.
Booking: /book page — pick doctor, branch, date, slot; the doctor instantly receives email + WhatsApp alert.
Contact: +91 99245 19705, +91 63528 45195, ${SITE.emails.general}. Facebook: /balarkayurveda, Instagram: @balark_ayurveda_and_panchkarma.`;

type Reply = { reply: string; doctors?: unknown[]; links?: { label: string; href: string }[] };

async function localBrain(message: string): Promise<Reply> {
  const m = message.toLowerCase();
  const docs = await db.select().from(doctors).orderBy(asc(doctors.sortOrder));
  const cards = docs.map((d) => ({
    name: d.name,
    role: d.role,
    qualifications: d.qualifications,
    image: d.image,
  }));

  if (/(book|appointment|slot|schedule|reserve)/.test(m)) {
    return {
      reply:
        "Booking takes three calm steps: choose your doctor, pick branch + date + slot, then tell us the reason. The doctor gets an instant email and WhatsApp alert with your details. Shall I open the booking page?",
      links: [{ label: "Book Appointment", href: "/book" }, { label: "Meet the doctors", href: "/doctors" }],
    };
  }
  if (/(doctor|vaidya|chirag|dhruva|who will treat|specialist)/.test(m)) {
    return {
      reply:
        "Our two healers: Dr Chirag Vyas (B.A.M.S, P.G. C.P.K, Medical Astrology) leads physician consults, joint & spine care and Panchakarma protocols. Dhruva Vyas is our Ayurveda pharmacist and female Panchakarma therapy expert — Balark hair oils, Dhruva herbal beauty and women's therapies. Both have 17+ years and 35,000+ patients of experience.",
      doctors: cards,
      links: [{ label: "Book with a doctor", href: "/doctors" }],
    };
  }
  if (/(price|cost|fee|charge|kitna|payment|pay|razorpay|upi)/.test(m)) {
    return {
      reply:
        "We don't publish fixed prices — every Panchakarma protocol is personalised after consultation, so fees are decided by the doctor. Our online payment gateway is coming soon; until then booking is completely free and you pay at the clinic.",
      links: [{ label: "Book free consultation", href: "/book" }],
    };
  }
  if (/(time|timing|hour|open|close|when|Sunday|holiday)/.test(m)) {
    return {
      reply:
        "We're open Monday to Saturday, 9:00 AM – 1:00 PM and 4:00 PM – 8:00 PM. Sundays are by prior appointment only. Online consultation is available at your convenience.",
      links: [{ label: "See slots", href: "/book" }],
    };
  }
  if (/(where|location|address|branch|map|direction|reach)/.test(m)) {
    return {
      reply: `Two branches: ${LOCATIONS[0].name} — ${LOCATIONS[0].address}; and ${LOCATIONS[1].name} — ${LOCATIONS[1].address}. Full maps with directions are on the contact page.`,
      links: [{ label: "Maps & directions", href: "/contact" }],
    };
  }
  if (/(treatment|therapy|therapies|panchakarma|shirodhara|abhyanga|basti|nasya|detox|facial|kizhi)/.test(m)) {
    const treats = await db.select().from(treatments).orderBy(asc(treatments.sortOrder));
    const names = treats.filter((t) => !t.comingSoon).slice(0, 8).map((t) => t.name).join(", ");
    return {
      reply: `Our signature therapies include ${names} and more — plus new classical procedures added as our patients need them. Each treatment page explains benefits and session flow, with a Book Appointment button instead of prices.`,
      links: [{ label: "Browse treatments", href: "/treatments" }],
    };
  }
  if (/(hair|skin|face|acne|dandruff|fall)/.test(m)) {
    return {
      reply:
        "For hair and skin we offer Ayurvedic Facial (Mukha Lepa), Dhruva Hair Care Therapy with Balark's specialised hair oils, and Udvartana for skin tone — plus Dhruva herbal beauty products prepared in-house by Dhruva Vyas.",
      links: [{ label: "Hair & skin therapies", href: "/treatments?cat=Hair%20%26%20Skin" }, { label: "Book", href: "/book" }],
    };
  }
  if (/(joint|knee|back|spine|sciatica|arthritis|shoulder|pain)/.test(m)) {
    return {
      reply:
        "Joint and spine care is our deepest specialty: Kati Basti for lumbar pain, Janu Basti for knees, plus Abhyanga, Navarakizhi and Panchakarma protocols for arthritis, sciatica and frozen shoulder — 35,000+ patients treated since 2008.",
      links: [{ label: "Book joint & spine consult", href: "/book" }],
    };
  }
  if (/(whatsapp|call|phone|contact|number)/.test(m)) {
    return {
      reply: `Call or WhatsApp us: ${SITE.phones[0].label} or ${SITE.phones[1].label}. Email ${SITE.emails.general}. The green WhatsApp button on this site reaches the clinic desk directly.`,
      links: [{ label: "Contact page", href: "/contact" }],
    };
  }
  if (/(hello|hi|namaste|hey|good)/.test(m)) {
    return {
      reply: "Namaste 🙏 Welcome to Balark Ayurveda. I can help with treatments, doctors, timings, locations, fees or booking. What would you like to know?",
      links: [{ label: "Book Appointment", href: "/book" }],
    };
  }
  return {
    reply:
      "I can help with: treatments & Panchakarma therapies, our doctors, clinic timings, both branch locations, fees & payments, or booking an appointment. Which one shall we explore?",
    links: [{ label: "Book Appointment", href: "/book" }, { label: "Treatments", href: "/treatments" }],
  };
}

export async function POST(req: Request) {
  const { message } = (await req.json().catch(() => ({}))) as { message?: string };
  if (!message || typeof message !== "string") {
    return NextResponse.json({ error: "Message required" }, { status: 400 });
  }

  const key = process.env.OPENAI_API_KEY;
  if (key) {
    try {
      const res = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          model: process.env.OPENAI_MODEL ?? "gpt-4o-mini",
          temperature: 0.4,
          messages: [
            {
              system: `You are Balark Seva AI, the warm and concise website assistant of ${SITE.name} (Ayurveda & Panchakarma, Gujarat, India). Answer only from these facts and always steer patients towards booking (/book) or WhatsApp when medical advice is requested. Never diagnose; recommend consultation. Facts:\n${CLINIC_FACTS}`,
            } as unknown as { role: string; content: string },
            { role: "user", content: message },
          ],
        }),
      });
      if (res.ok) {
        const data = await res.json();
        const reply = data?.choices?.[0]?.message?.content as string | undefined;
        if (reply) return NextResponse.json({ reply });
      }
    } catch {
      /* fall through to local brain */
    }
  }

  const out = await localBrain(message);
  return NextResponse.json(out);
}
