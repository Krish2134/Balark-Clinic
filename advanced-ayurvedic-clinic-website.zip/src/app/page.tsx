import Link from "next/link";
import { db } from "@/db";
import { doctors, testimonials, treatments } from "@/db/schema";
import { asc, desc, eq } from "drizzle-orm";
import Reveal from "@/components/Reveal";
import Counter from "@/components/Counter";
import Stars from "@/components/Stars";
import TreatmentCard from "@/components/TreatmentCard";
import { LogoMark } from "@/components/Logo";
import { LOCATIONS, SITE, waLink } from "@/lib/site";

export const dynamic = "force-dynamic";

const HERO_IMG =
  "https://images.pexels.com/photos/6628603/pexels-photo-6628603.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200";

const PILLARS = [
  {
    title: "Advanced Panchakarma Therapies",
    text: "Classical Vaman, Virechan, Basti, Nasya and Raktamokshana protocols performed under strict supervision.",
    icon: (
      <path d="M12 3c3 3.5 4.5 6.6 4.5 9.4A4.5 4.5 0 0 1 12 17a4.5 4.5 0 0 1-4.5-4.6C7.5 9.6 9 6.5 12 3zM6 21h12" strokeLinecap="round" />
    ),
  },
  {
    title: "Specialised Joint & Spine Care",
    text: "Arthritis, sciatica, frozen shoulder, slip disc and chronic back pain treated from the root cause.",
    icon: (
      <path d="M8 4v4m0 4v4m0 4v0M16 4v4m0 4v4m0 4v0M8 8h8M8 16h8" strokeLinecap="round" />
    ),
  },
  {
    title: "Female Health & Wellness",
    text: "Dedicated female Panchakarma expert, private therapy rooms and women-centric herbal care.",
    icon: (
      <path d="M12 21s-7-4.6-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 11c0 5.4-7 10-7 10z" strokeLinejoin="round" />
    ),
  },
  {
    title: "In-house Ayurveda Pharmacy",
    text: "Specialised Balark hair oils, Panchakarma oils and Dhruva herbal beauty products prepared on site.",
    icon: (
      <path d="M9 3h6M10 3v6l-5 9a2.4 2.4 0 0 0 2.1 3.5h9.8A2.4 2.4 0 0 0 19 18l-5-9V3" strokeLinecap="round" strokeLinejoin="round" />
    ),
  },
  {
    title: "Modern Diagnostic Approach",
    text: "Nadi pariksha paired with modern reports so every protocol is measured, tracked and personalised.",
    icon: (
      <path d="M3 12h4l2.5-6 4 12L16 12h5" strokeLinecap="round" strokeLinejoin="round" />
    ),
  },
  {
    title: "Peaceful & Hygienic Environment",
    text: "100% organic certified oils, single-use linens and calm, private therapy spaces at both branches.",
    icon: (
      <path d="M12 3l8 4v5c0 5-3.4 8.3-8 9-4.6-.7-8-4-8-9V7l8-4zM9 12l2.2 2.2L15.5 10" strokeLinecap="round" strokeLinejoin="round" />
    ),
  },
];

const UPCOMING = [
  "Agnikarma",
  "Ksharasutra Care",
  "Jalaukavacharana (Leech Therapy)",
  "Pizhichil (Oil Bath)",
  "Shashtika Shali Navarakizhi",
  "Marma Chikitsa",
  "Vaman & Virechan Camps",
];

export default async function Home() {
  const [featured, comingSoonList, docs, reviews] = await Promise.all([
    db.select().from(treatments).where(eq(treatments.featured, true)).orderBy(asc(treatments.sortOrder)),
    db.select().from(treatments).where(eq(treatments.comingSoon, true)).orderBy(asc(treatments.sortOrder)),
    db.select().from(doctors).orderBy(asc(doctors.sortOrder)),
    db.select().from(testimonials).where(eq(testimonials.approved, true)).orderBy(desc(testimonials.createdAt)).limit(6),
  ]);

  const marqueeNames = featured.map((t) => t.name).concat(["Nasya Karma", "Takradhara", "Janu Basti", "Udvartana"]);

  return (
    <>
      {/* ================= HERO ================= */}
      <section className="relative overflow-hidden">
        <div className="mx-auto grid max-w-7xl items-center gap-14 px-6 pt-14 pb-20 lg:grid-cols-[1.05fr_0.95fr] lg:pt-20">
          <div>
            <Reveal>
              <p className="inline-flex items-center gap-2 rounded-full border border-sage/40 bg-sage/10 px-4 py-1.5 text-[0.68rem] font-bold tracking-[0.2em] text-sage-deep uppercase">
                <span className="h-1.5 w-1.5 rounded-full bg-sage" />
                Since {SITE.since} • Gandhinagar & Visnagar
              </p>
            </Reveal>
            <Reveal delay={100}>
              <h1 className="mt-6 font-display text-[clamp(2.8rem,6vw,4.6rem)] leading-[1.02] font-semibold text-brown-deep">
                <span className="line-mask">
                  <span>Ancient Ayurveda,</span>
                </span>
                <span className="line-mask" style={{ "--reveal-delay": "120ms" } as React.CSSProperties}>
                  <span>
                    practised with <em className="text-sage-deep italic">modern</em>
                  </span>
                </span>
                <span className="line-mask" style={{ "--reveal-delay": "240ms" } as React.CSSProperties}>
                  <span>precision.</span>
                </span>
              </h1>
            </Reveal>
            <Reveal delay={220}>
              <p className="mt-6 max-w-xl text-[1.02rem] leading-relaxed text-ink/75">
                {SITE.name} heals joint, spine, skin, hair and lifestyle disorders through
                classical Panchakarma — personalised by our physicians, powered by our own
                in-house herbal pharmacy.
              </p>
            </Reveal>
            <Reveal delay={320}>
              <div className="mt-8 flex flex-wrap items-center gap-4">
                <Link
                  href="/book"
                  className="rounded-full bg-sage px-7 py-3.5 text-sm font-bold tracking-wide text-cream shadow-[0_18px_36px_-16px_rgba(63,107,71,0.9)] transition hover:-translate-y-1 hover:bg-sage-deep"
                >
                  Book an Appointment
                </Link>
                <Link
                  href="/treatments"
                  className="rounded-full border-2 border-brown/25 px-7 py-3.5 text-sm font-bold tracking-wide text-brown transition hover:-translate-y-1 hover:border-gold hover:text-gold"
                >
                  Explore Treatments
                </Link>
                <a
                  href={waLink(SITE.primaryWhatsapp, "Namaste 🙏 I want to consult an Ayurveda doctor at Balark Clinic.")}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 text-sm font-bold text-[#128C4B] underline-offset-4 hover:underline"
                >
                  <svg viewBox="0 0 24 24" className="h-4.5 w-4.5 fill-current">
                    <path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5.1-1.3A10 10 0 1 0 12 2zm5.4 14.1c-.2.7-1.3 1.3-1.9 1.4-.5.1-1.1.1-1.8-.1-.4-.1-1-.3-1.7-.6-3-1.3-4.9-4.3-5.1-4.5-.1-.2-1.2-1.6-1.2-3.1s.8-2.2 1-2.5c.3-.3.6-.4.8-.4h.6c.2 0 .4 0 .6.5s.8 1.9.8 2c.1.1.1.3 0 .5-.3.6-.7.9-.5 1.2.7 1.2 1.6 2 2.8 2.6.3.2.5.1.7-.1l.9-1c.2-.3.4-.2.7-.1l2 1c.3.1.5.2.6.4 0 .1 0 .7-.3 1.3z" />
                  </svg>
                  WhatsApp us
                </a>
              </div>
            </Reveal>
            <Reveal delay={420}>
              <dl className="mt-12 grid max-w-xl grid-cols-2 gap-6 border-t border-brown/15 pt-8 sm:grid-cols-4">
                {[
                  { n: 17, s: "+", l: "Years of practice" },
                  { n: 35000, s: "+", l: "Patients treated" },
                  { n: 40, s: "+", l: "Therapies offered" },
                  { n: 2, s: "", l: "Clinic branches" },
                ].map((s) => (
                  <div key={s.l}>
                    <dt className="font-display text-3xl font-bold text-sage-deep">
                      <Counter to={s.n} suffix={s.s} />
                    </dt>
                    <dd className="mt-1 text-[0.7rem] font-semibold tracking-[0.14em] text-ink/60 uppercase">
                      {s.l}
                    </dd>
                  </div>
                ))}
              </dl>
            </Reveal>
          </div>

          {/* hero visual */}
          <Reveal delay={200} className="relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              <div className="arch relative overflow-hidden border-8 border-paper shadow-[0_40px_80px_-32px_rgba(59,36,31,0.55)]">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={HERO_IMG}
                  alt="Shirodhara therapy at Balark Ayurveda and Panchakarma Clinic"
                  className="anim-kenburns h-[30rem] w-full object-cover lg:h-[34rem]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-cocoa/50 via-transparent to-transparent" />
              </div>

              {/* logo highlight badge */}
              <div className="anim-float absolute -top-6 -left-6 flex items-center gap-3 rounded-2xl border border-brown/10 bg-paper/95 px-4 py-3 shadow-xl backdrop-blur">
                <LogoMark className="h-11 w-11" />
                <span className="leading-none">
                  <span className="block font-body text-lg font-extrabold tracking-[0.08em] text-brown">
                    BALARK
                  </span>
                  <span className="mt-1 block text-[0.5rem] font-bold tracking-[0.22em] text-brown/60 uppercase">
                    Ayurveda & Panchakarma
                  </span>
                </span>
              </div>

              <div className="anim-float-slow absolute -right-4 bottom-16 rounded-2xl border border-brown/10 bg-paper/95 px-4 py-3 shadow-xl backdrop-blur">
                <p className="text-[0.62rem] font-bold tracking-[0.18em] text-sage-deep uppercase">100% Organic</p>
                <p className="mt-1 text-xs text-ink/70">Certified oils & herbs</p>
              </div>

              <div className="absolute -bottom-6 left-8 flex items-center gap-2 rounded-full bg-cocoa px-5 py-2.5 text-cream shadow-xl">
                <span className="relative flex h-2 w-2">
                  <span className="absolute h-full w-full animate-ping rounded-full bg-[#25D366] opacity-75" />
                  <span className="relative h-2 w-2 rounded-full bg-[#25D366]" />
                </span>
                <span className="text-[0.7rem] font-semibold tracking-wide">Offline & online consultation</span>
              </div>
            </div>
          </Reveal>
        </div>

        {/* marquee */}
        <div className="marquee-mask relative overflow-hidden border-y border-brown/10 bg-sage-deep py-3.5">
          <div className="anim-marquee flex w-max gap-10">
            {[...marqueeNames, ...marqueeNames].map((n, i) => (
              <span key={i} className="flex items-center gap-10 text-[0.78rem] font-bold tracking-[0.22em] text-cream/85 uppercase">
                {n}
                <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 fill-gold">
                  <path d="M12 2c4 5 6 9.4 6 13.4A6 6 0 0 1 12 21a6 6 0 0 1-6-5.6C6 11.4 8 7 12 2z" />
                </svg>
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* ================= PILLARS ================= */}
      <section className="mx-auto max-w-7xl px-6 py-20">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="text-[0.68rem] font-bold tracking-[0.24em] text-gold uppercase">Why Balark</p>
          <h2 className="mt-3 font-display text-4xl font-semibold text-brown-deep sm:text-5xl">
            A clinic built on six promises
          </h2>
          <p className="mt-4 text-ink/70">
            The same facilities our patients have trusted since {SITE.since} — now with online
            booking, AI assistance and doctor-side instant alerts.
          </p>
        </Reveal>
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {PILLARS.map((p, i) => (
            <Reveal key={p.title} delay={i * 80}>
              <div className="card-lift group h-full rounded-2xl border border-brown/12 bg-paper p-7">
                <span className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-sage/12 text-sage-deep transition group-hover:bg-sage group-hover:text-cream">
                  <svg viewBox="0 0 24 24" className="h-6 w-6 fill-none stroke-current" strokeWidth="1.8">
                    {p.icon}
                  </svg>
                </span>
                <h3 className="mt-5 font-display text-2xl font-semibold text-brown">{p.title}</h3>
                <p className="mt-2.5 text-sm leading-relaxed text-ink/70">{p.text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ================= FEATURED TREATMENTS ================= */}
      <section className="relative bg-cream-deep/60 py-20">
        <div className="mx-auto max-w-7xl px-6">
          <Reveal className="flex flex-wrap items-end justify-between gap-6">
            <div className="max-w-xl">
              <p className="text-[0.68rem] font-bold tracking-[0.24em] text-gold uppercase">Signature therapies</p>
              <h2 className="mt-3 font-display text-4xl font-semibold text-brown-deep sm:text-5xl">
                Treatments our patients travel for
              </h2>
            </div>
            <Link
              href="/treatments"
              className="rounded-full border-2 border-brown/25 px-6 py-3 text-sm font-bold text-brown transition hover:border-sage hover:bg-sage hover:text-cream"
            >
              View all treatments
            </Link>
          </Reveal>

          <div className="mt-12 grid gap-7 sm:grid-cols-2 lg:grid-cols-3">
            {featured.map((t, i) => (
              <Reveal key={t.slug} delay={(i % 3) * 90}>
                <TreatmentCard t={t} />
              </Reveal>
            ))}
          </div>

          <Reveal delay={120}>
            <p className="mt-10 flex flex-wrap items-center justify-center gap-3 rounded-2xl border border-gold/40 bg-gold/10 px-6 py-4 text-center text-sm text-brown-deep">
              <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-gold" strokeWidth="2">
                <rect x="3" y="10" width="18" height="10" rx="2" />
                <path d="M8 10V7a4 4 0 0 1 8 0v3" />
              </svg>
              <span>
                <strong className="font-bold">No prices listed — on purpose.</strong> Every protocol is
                personalised after consultation. Our online payment gateway is{" "}
                <strong className="font-bold">coming soon</strong>; until then, book free and pay at the clinic.
              </span>
            </p>
          </Reveal>
        </div>
      </section>

      {/* ================= THERAPIES GROWING ================= */}
      <section className="mx-auto max-w-7xl px-6 py-20">
        <div className="grid items-center gap-12 lg:grid-cols-[0.9fr_1.1fr]">
          <Reveal>
            <p className="text-[0.68rem] font-bold tracking-[0.24em] text-gold uppercase">A living therapy menu</p>
            <h2 className="mt-3 font-display text-4xl leading-tight font-semibold text-brown-deep sm:text-5xl">
              Our therapies keep growing — <span className="text-sage-deep italic">with our patients’ needs.</span>
            </h2>
            <p className="mt-5 leading-relaxed text-ink/75">
              Every season, our physicians review the conditions walking through our doors and add
              the classical procedures that serve them best. These therapies are currently being
              standardised in our therapy rooms and will open for booking soon.
            </p>
            <div className="mt-7 flex flex-wrap gap-2.5">
              {UPCOMING.map((u) => (
                <span
                  key={u}
                  className="rounded-full border border-dashed border-sage/60 bg-sage/8 px-4 py-2 text-[0.72rem] font-bold tracking-wide text-sage-deep"
                >
                  {u}
                </span>
              ))}
            </div>
            <Link
              href="/contact"
              className="mt-8 inline-block rounded-full bg-brown px-6 py-3 text-sm font-bold text-cream transition hover:-translate-y-0.5 hover:bg-brown-deep"
            >
              Request a therapy for your condition
            </Link>
          </Reveal>
          <div className="grid gap-5 sm:grid-cols-2">
            {comingSoonList.map((t, i) => (
              <Reveal key={t.slug} delay={i * 90}>
                <div className="relative flex h-full min-h-44 flex-col justify-between overflow-hidden rounded-2xl border-2 border-dashed border-sage/50 bg-paper/70 p-6">
                  <span className="absolute -top-3 -right-3 rotate-6 rounded-full bg-gold px-3 py-1 text-[0.6rem] font-extrabold tracking-[0.16em] text-cocoa uppercase shadow">
                    Adding soon
                  </span>
                  <div>
                    <p className="text-[0.62rem] font-bold tracking-[0.18em] text-sage-deep uppercase">{t.category}</p>
                    <h3 className="mt-2 font-display text-2xl font-semibold text-brown">{t.name}</h3>
                  </div>
                  <p className="mt-3 text-sm text-ink/65">{t.tagline}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ================= DOCTORS ================= */}
      <section className="bg-cocoa py-20 text-cream">
        <div className="mx-auto max-w-7xl px-6">
          <Reveal className="mx-auto max-w-2xl text-center">
            <p className="text-[0.68rem] font-bold tracking-[0.24em] text-gold uppercase">The healers</p>
            <h2 className="mt-3 font-display text-4xl font-semibold sm:text-5xl">Meet your doctors</h2>
          </Reveal>
          <div className="mt-14 grid gap-8 lg:grid-cols-2">
            {docs.map((d, i) => (
              <Reveal key={d.slug} delay={i * 120}>
                <article className="card-lift grid overflow-hidden rounded-3xl border border-cream/12 bg-brown-deep/60 sm:grid-cols-[0.85fr_1.15fr]">
                  <div className="relative h-64 overflow-hidden sm:h-full">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={d.image} alt={d.name} className="h-full w-full object-cover object-top" />
                    <div className="absolute inset-0 bg-gradient-to-t from-brown-deep/70 to-transparent sm:bg-gradient-to-r" />
                  </div>
                  <div className="p-7">
                    <h3 className="font-display text-3xl font-semibold text-cream">{d.name}</h3>
                    <p className="mt-1 text-[0.72rem] font-bold tracking-[0.14em] text-gold uppercase">
                      {d.qualifications}
                    </p>
                    <p className="mt-3 text-sm text-cream/75">{d.role}</p>
                    <ul className="mt-4 grid gap-1.5 text-[0.82rem] text-cream/85">
                      {d.specialties.slice(0, 3).map((s) => (
                        <li key={s} className="flex gap-2">
                          <svg viewBox="0 0 24 24" className="mt-0.5 h-3.5 w-3.5 shrink-0 fill-none stroke-gold" strokeWidth="2.4">
                            <path d="M5 13l4 4L19 7" strokeLinecap="round" strokeLinejoin="round" />
                          </svg>
                          {s}
                        </li>
                      ))}
                    </ul>
                    <div className="mt-5 flex flex-wrap gap-3">
                      <Link
                        href={`/book?doctor=${d.slug}`}
                        className="rounded-full bg-sage px-5 py-2.5 text-[0.72rem] font-bold tracking-wide text-cream transition hover:bg-sage-deep"
                      >
                        Book with {d.name.split(" ")[0] === "Dr" ? d.name.split(" ")[1] : d.name.split(" ")[0]}
                      </Link>
                      <a
                        href={waLink(d.whatsapp, `Namaste ${d.name}, I would like to book a consultation at Balark Clinic.`)}
                        target="_blank"
                        rel="noreferrer"
                        className="rounded-full border border-cream/25 px-5 py-2.5 text-[0.72rem] font-bold tracking-wide text-cream transition hover:border-[#25D366] hover:text-[#25D366]"
                      >
                        WhatsApp
                      </a>
                    </div>
                  </div>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ================= BOOKING FLOW ================= */}
      <section className="mx-auto max-w-7xl px-6 py-20">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="text-[0.68rem] font-bold tracking-[0.24em] text-gold uppercase">Advanced appointment system</p>
          <h2 className="mt-3 font-display text-4xl font-semibold text-brown-deep sm:text-5xl">
            Booked in four calm steps
          </h2>
          <p className="mt-4 text-ink/70">
            Choose your doctor, pick a slot that suits you, and rest easy — the moment you confirm,
            your doctor is alerted by <strong className="font-bold">email and WhatsApp</strong> with
            your name, time and reason for visit.
          </p>
        </Reveal>
        <ol className="mt-14 grid gap-6 md:grid-cols-4">
          {[
            { t: "Select your doctor", d: "Dr Chirag Vyas for physician consults, Dhruva Vyas for pharmacy & female Panchakarma therapy." },
            { t: "Choose branch, date & slot", d: "Live slot availability for Gandhinagar and Visnagar — no double bookings, ever." },
            { t: "Tell us the reason", d: "Your complaint and preferred therapy help the doctor prepare before you arrive." },
            { t: "Doctor notified instantly", d: "Email + WhatsApp alert to the doctor with your details, plus a WhatsApp confirmation for you." },
          ].map((s, i) => (
            <Reveal key={s.t} delay={i * 100} as="li">
              <div className="relative h-full rounded-2xl border border-brown/12 bg-paper p-6 pt-9">
                <span className="absolute -top-5 left-6 flex h-10 w-10 items-center justify-center rounded-full bg-gold font-display text-lg font-bold text-cocoa shadow-lg">
                  {i + 1}
                </span>
                <h3 className="font-display text-xl font-semibold text-brown">{s.t}</h3>
                <p className="mt-2 text-sm leading-relaxed text-ink/70">{s.d}</p>
              </div>
            </Reveal>
          ))}
        </ol>
        <Reveal delay={200} className="mt-10 text-center">
          <Link
            href="/book"
            className="inline-block rounded-full bg-sage px-9 py-4 text-sm font-bold tracking-wide text-cream shadow-[0_18px_36px_-16px_rgba(63,107,71,0.9)] transition hover:-translate-y-1 hover:bg-sage-deep"
          >
            Start your booking
          </Link>
        </Reveal>
      </section>

      {/* ================= TESTIMONIALS ================= */}
      <section className="bg-cream-deep/60 py-20">
        <div className="mx-auto max-w-7xl px-6">
          <Reveal className="flex flex-wrap items-end justify-between gap-6">
            <div>
              <p className="text-[0.68rem] font-bold tracking-[0.24em] text-gold uppercase">Patient stories</p>
              <h2 className="mt-3 font-display text-4xl font-semibold text-brown-deep sm:text-5xl">
                Healing, in their words
              </h2>
            </div>
            <Link href="/testimonials" className="text-sm font-bold text-sage-deep underline-offset-4 hover:underline">
              Read all reviews →
            </Link>
          </Reveal>
          <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {reviews.map((r, i) => (
              <Reveal key={r.id} delay={(i % 3) * 90}>
                <figure
                  className={`card-lift relative h-full rounded-2xl border border-brown/12 bg-paper p-7 ${
                    i % 3 === 1 ? "lg:translate-y-6" : ""
                  }`}
                >
                  <svg viewBox="0 0 24 24" className="h-8 w-8 fill-gold/30">
                    <path d="M10 7H6a3 3 0 0 0-3 3v7h7v-7H7c0-1.7 1.3-3 3-3V7zm11 0h-4a3 3 0 0 0-3 3v7h7v-7h-3c0-1.7 1.3-3 3-3V7z" />
                  </svg>
                  <blockquote className="mt-4 text-[0.95rem] leading-relaxed text-ink/80">“{r.body}”</blockquote>
                  <figcaption className="mt-5 flex items-center justify-between border-t border-brown/10 pt-4">
                    <div>
                      <p className="font-display text-lg font-semibold text-brown">{r.name}</p>
                      <p className="text-[0.7rem] tracking-wide text-ink/55">
                        {r.location} • {r.treatment}
                      </p>
                    </div>
                    <Stars rating={r.rating} />
                  </figcaption>
                </figure>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ================= LOCATIONS ================= */}
      <section className="mx-auto max-w-7xl px-6 py-20">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="text-[0.68rem] font-bold tracking-[0.24em] text-gold uppercase">Two branches, one promise</p>
          <h2 className="mt-3 font-display text-4xl font-semibold text-brown-deep sm:text-5xl">Find us on the map</h2>
        </Reveal>
        <div className="mt-12 grid gap-7 md:grid-cols-2">
          {LOCATIONS.map((l, i) => (
            <Reveal key={l.key} delay={i * 120}>
              <div className="card-lift overflow-hidden rounded-2xl border border-brown/12 bg-paper">
                <div className="h-56 overflow-hidden">
                  <iframe
                    src={l.mapEmbed}
                    title={`Map of ${l.name}`}
                    loading="lazy"
                    referrerPolicy="strict-origin-when-cross-origin"
                    className="h-full w-full border-0"
                  />
                </div>
                <div className="flex flex-wrap items-center justify-between gap-4 p-6">
                  <div>
                    <h3 className="font-display text-2xl font-semibold text-brown">{l.name}</h3>
                    <p className="mt-1 text-sm text-ink/65">{l.address}</p>
                    <p className="mt-1 text-sm font-semibold text-sage-deep">{l.phone}</p>
                  </div>
                  <a
                    href={l.directions}
                    target="_blank"
                    rel="noreferrer"
                    className="rounded-full border-2 border-sage/50 px-5 py-2.5 text-[0.72rem] font-bold tracking-wide text-sage-deep transition hover:bg-sage hover:text-cream"
                  >
                    Get Directions
                  </a>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ================= CTA ================= */}
      <section className="relative overflow-hidden bg-sage-deep py-20 text-cream">
        <LogoMark className="pointer-events-none absolute -right-16 -bottom-20 h-80 w-80 opacity-10" />
        <div className="relative mx-auto max-w-4xl px-6 text-center">
          <Reveal>
            <h2 className="font-display text-4xl leading-tight font-semibold sm:text-5xl">
              Begin your healing journey at the root cause
            </h2>
            <p className="mx-auto mt-5 max-w-2xl text-cream/80">
              Offline consultations at Gandhinagar & Visnagar, or online from anywhere in the world.
              Your doctor is notified the moment you book.
            </p>
            <div className="mt-9 flex flex-wrap justify-center gap-4">
              <Link
                href="/book"
                className="rounded-full bg-cream px-8 py-4 text-sm font-bold tracking-wide text-sage-deep shadow-xl transition hover:-translate-y-1"
              >
                Book an Appointment
              </Link>
              <a
                href={SITE.phones[0].href}
                className="rounded-full border-2 border-cream/40 px-8 py-4 text-sm font-bold tracking-wide transition hover:-translate-y-1 hover:border-cream"
              >
                Call {SITE.phones[0].label}
              </a>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
