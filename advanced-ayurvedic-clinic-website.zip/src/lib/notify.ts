/**
 * Notification delivery for appointment alerts.
 *
 * Email  → uses RESEND_API_KEY when present (https://api.resend.com/emails).
 * WhatsApp → uses Meta WhatsApp Cloud API when WHATSAPP_CLOUD_TOKEN +
 *            WHATSAPP_PHONE_ID are present.
 *
 * Without credentials the notification is stored as "queued" so nothing is
 * lost — the doctor dashboard shows exactly what is pending, and delivery
 * switches on automatically the moment keys are added to .env.
 */

export type DeliveryResult = { status: "sent" | "queued" | "failed"; detail: string };

export async function sendEmail(to: string, subject: string, text: string): Promise<DeliveryResult> {
  const key = process.env.RESEND_API_KEY;
  if (!key) return { status: "queued", detail: "RESEND_API_KEY not configured — stored in outbox" };
  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: process.env.EMAIL_FROM ?? "Balark Clinic <appointments@balarkayurved.com>",
        to: [to],
        subject,
        text,
      }),
    });
    if (!res.ok) return { status: "failed", detail: `Resend responded ${res.status}` };
    return { status: "sent", detail: "Delivered via Resend" };
  } catch (e) {
    return { status: "failed", detail: e instanceof Error ? e.message : "network error" };
  }
}

export async function sendWhatsApp(to: string, text: string): Promise<DeliveryResult> {
  const token = process.env.WHATSAPP_CLOUD_TOKEN;
  const phoneId = process.env.WHATSAPP_PHONE_ID;
  if (!token || !phoneId) {
    return { status: "queued", detail: "WhatsApp Cloud API keys not configured — stored in outbox" };
  }
  try {
    const digits = to.replace(/\D/g, "");
    const res = await fetch(`https://graph.facebook.com/v20.0/${phoneId}/messages`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        messaging_product: "whatsapp",
        to: digits,
        type: "text",
        text: { body: text },
      }),
    });
    if (!res.ok) return { status: "failed", detail: `Meta API responded ${res.status}` };
    return { status: "sent", detail: "Delivered via WhatsApp Cloud API" };
  } catch (e) {
    return { status: "failed", detail: e instanceof Error ? e.message : "network error" };
  }
}
