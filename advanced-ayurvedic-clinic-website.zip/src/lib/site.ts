export const SITE = {
  name: "Balark Ayurveda and Panchakarma Clinic",
  shortName: "BALARK",
  sub: "Ayurveda and Panchakarma Clinic",
  tagline: "True healing begins from the root cause, not just temporary relief.",
  since: 2008,
  emails: {
    general: "info@balarkayurved.com",
    appointments: "appointments@balarkayurved.com",
  },
  phones: [
    { label: "+91 99245 19705", href: "tel:+919924519705" },
    { label: "+91 63528 45195", href: "tel:+916352845195" },
  ],
  primaryWhatsapp: "919924519705",
  socials: {
    facebook: "https://www.facebook.com/balarkayurveda/",
    instagram:
      "https://www.instagram.com/balark_ayurveda_and_panchkarma?utm_source=ig_web_button_share_sheet&igsi=ZDNlZDc0MzIxNw==",
  },
  hours: [
    { days: "Monday – Saturday", time: "9:00 AM – 1:00 PM • 4:00 PM – 8:00 PM" },
    { days: "Sunday", time: "By prior appointment only" },
  ],
};

export const NAV = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About" },
  { href: "/treatments", label: "Treatments" },
  { href: "/doctors", label: "Doctors" },
  { href: "/testimonials", label: "Testimonials" },
  { href: "/blog", label: "Blog" },
  { href: "/contact", label: "Contact" },
];

export const LOCATIONS = [
  {
    key: "gandhinagar",
    name: "Gandhinagar Branch",
    title: "Balark Ayurveda And Panchakarma Clinic",
    address: "Kudasan, Gandhinagar, Gujarat 382421",
    phone: "+91 99245 19705",
    mapEmbed:
      "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3667.8054442057137!2d72.6314206!3d23.177299899999998!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395c2baac65cf4b5%3A0x1e4935307be8cf80!2sBalark%20Ayurveda%20And%20Panchakarma%20Clinic!5e0!3m2!1sen!2sin!4v1788455334973!5m2!1sen!2sin",
    directions:
      "https://www.google.com/maps/search/?api=1&query=Balark+Ayurveda+And+Panchakarma+Clinic+Kudasan+Gandhinagar",
  },
  {
    key: "visnagar",
    name: "Visnagar Branch",
    title:
      "Balark Ayurveda And Panchakarma Clinic – Best Joint Clinic, Spine Care Clinic, Hair And Skin Ayurveda Care Clinic",
    address: "Visnagar, Mahesana, Gujarat 384315",
    phone: "+91 63528 45195",
    mapEmbed:
      "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3653.2125021642696!2d72.5454355!3d23.704104299999994!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395c4f44a1d4df05%3A0x8450c65b1e60937d!2sBalark%20Ayurveda%20And%20Panchakarma%20Clinic%20-%20Best%20Joint%20Clinic%2C%20Spine%20Care%20Clinic%2C%20Hair%20And%20Skin%20Ayurveda%20Care%20Clinic!5e0!3m2!1sen!2sin!4v1788455366088!5m2!1sen!2sin",
    directions:
      "https://www.google.com/maps/search/?api=1&query=Balark+Ayurveda+And+Panchakarma+Clinic+Visnagar",
  },
];

export const TIME_SLOTS = [
  "09:00 AM",
  "09:45 AM",
  "10:30 AM",
  "11:15 AM",
  "12:00 PM",
  "12:45 PM",
  "04:00 PM",
  "04:45 PM",
  "05:30 PM",
  "06:15 PM",
  "07:00 PM",
  "07:45 PM",
];

export function waLink(number: string, message: string) {
  return `https://wa.me/${number}?text=${encodeURIComponent(message)}`;
}

export const WA_DEFAULT_MSG =
  "Namaste Balark Ayurveda 🙏 I would like to enquire about Panchakarma treatments and book an appointment.";
