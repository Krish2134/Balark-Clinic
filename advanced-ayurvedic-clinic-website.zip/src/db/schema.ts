import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
  jsonb,
} from "drizzle-orm/pg-core";

export const doctors = pgTable("doctors", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  role: text("role").notNull(),
  qualifications: text("qualifications").notNull(),
  image: text("image").notNull(),
  bio: text("bio").notNull(),
  specialties: jsonb("specialties").$type<string[]>().notNull(),
  experienceYears: integer("experience_years").notNull(),
  patientsTreated: text("patients_treated").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  whatsapp: text("whatsapp").notNull(),
  sortOrder: integer("sort_order").notNull().default(1),
});

export const treatments = pgTable("treatments", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  tagline: text("tagline").notNull(),
  description: text("description").notNull(),
  benefits: jsonb("benefits").$type<string[]>().notNull(),
  steps: jsonb("steps").$type<string[]>().notNull(),
  duration: text("duration").notNull(),
  image: text("image").notNull(),
  featured: boolean("featured").notNull().default(false),
  comingSoon: boolean("coming_soon").notNull().default(false),
  sortOrder: integer("sort_order").notNull().default(1),
});

export const testimonials = pgTable("testimonials", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  location: text("location").notNull(),
  rating: integer("rating").notNull().default(5),
  treatment: text("treatment").notNull(),
  body: text("body").notNull(),
  approved: boolean("approved").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const appointments = pgTable("appointments", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  patientName: text("patient_name").notNull(),
  phone: text("phone").notNull(),
  email: text("email"),
  doctorId: integer("doctor_id")
    .notNull()
    .references(() => doctors.id),
  location: text("location").notNull(),
  date: text("date").notNull(),
  timeSlot: text("time_slot").notNull(),
  treatmentSlug: text("treatment_slug"),
  reason: text("reason").notNull(),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  appointmentId: integer("appointment_id")
    .notNull()
    .references(() => appointments.id, { onDelete: "cascade" }),
  channel: text("channel").notNull(), // 'email' | 'whatsapp'
  recipient: text("recipient").notNull(),
  status: text("status").notNull().default("queued"), // sent | queued | failed
  detail: text("detail"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const posts = pgTable("posts", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  excerpt: text("excerpt").notNull(),
  content: text("content").notNull(),
  tag: text("tag").notNull(),
  author: text("author").notNull(),
  publishedAt: timestamp("published_at").notNull().defaultNow(),
});

export type Doctor = typeof doctors.$inferSelect;
export type Treatment = typeof treatments.$inferSelect;
export type Testimonial = typeof testimonials.$inferSelect;
export type Appointment = typeof appointments.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type Post = typeof posts.$inferSelect;
