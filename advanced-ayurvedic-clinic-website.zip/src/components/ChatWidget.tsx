"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { LogoMark } from "./Logo";
import { SITE, waLink } from "@/lib/site";

type DoctorCard = {
  name: string;
  role: string;
  qualifications: string;
  image: string;
};

type Msg = {
  role: "bot" | "user";
  text: string;
  doctors?: DoctorCard[];
  links?: { label: string; href: string }[];
};

const QUICK = ["Book an appointment", "Our treatments", "Meet the doctors", "Clinic timings", "Fees & payment"];

export default function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const [msgs, setMsgs] = useState<Msg[]>([
    {
      role: "bot",
      text: "Namaste 🙏 I am Balark Seva AI, your clinic assistant. Ask me about treatments, doctors, timings, two clinic locations or booking — or tap a quick option below.",
      links: [{ label: "Book Appointment", href: "/book" }],
    },
  ]);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [msgs, typing, open]);

  async function send(raw?: string) {
    const message = (raw ?? input).trim();
    if (!message || typing) return;
    setInput("");
    setMsgs((m) => [...m, { role: "user", text: message }]);
    setTyping(true);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message }),
      });
      const data = await res.json();
      setMsgs((m) => [
        ...m,
        { role: "bot", text: data.reply, doctors: data.doctors, links: data.links },
      ]);
    } catch {
      setMsgs((m) => [
        ...m,
        {
          role: "bot",
          text: "Sorry, I could not connect right now. Please call us at +91 99245 19705 or message on WhatsApp.",
        },
      ]);
    } finally {
      setTyping(false);
    }
  }

  return (
    <>
      <button
        onClick={() => setOpen((v) => !v)}
        aria-label="Open Balark AI assistant"
        className="fixed bottom-5 left-5 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-sage text-cream shadow-[0_16px_32px_-12px_rgba(63,107,71,0.8)] transition-transform hover:scale-110"
      >
        {open ? (
          <svg viewBox="0 0 24 24" className="h-6 w-6 fill-none stroke-current" strokeWidth="2.4">
            <path d="M6 6l12 12M18 6L6 18" strokeLinecap="round" />
          </svg>
        ) : (
          <svg viewBox="0 0 24 24" className="h-6 w-6 fill-none stroke-current" strokeWidth="1.9">
            <path d="M12 3a7 7 0 0 0-7 7v4.5A2.5 2.5 0 0 0 7.5 17H9v-6H7v-1a5 5 0 0 1 10 0v1h-2v6h3.2c.5 0 1-.2 1.3-.5" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M9 20h6" strokeLinecap="round" />
          </svg>
        )}
        {!open && (
          <span className="absolute -top-1 -right-1 flex h-4 w-4">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-gold opacity-70" />
            <span className="relative inline-flex h-4 w-4 rounded-full bg-gold" />
          </span>
        )}
      </button>

      <div
        className={`fixed bottom-24 left-5 z-50 flex w-[min(22.5rem,calc(100vw-2.5rem))] flex-col overflow-hidden rounded-2xl border border-brown/15 bg-paper shadow-[0_32px_64px_-24px_rgba(59,36,31,0.5)] transition-all duration-300 ${
          open ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-4 opacity-0"
        }`}
        role="dialog"
        aria-label="Balark AI assistant"
      >
        <div className="flex items-center gap-3 bg-cocoa px-4 py-3 text-cream">
          <span className="relative">
            <LogoMark className="h-9 w-9" />
            <span className="absolute -right-0.5 -bottom-0.5 h-2.5 w-2.5 rounded-full border-2 border-cocoa bg-[#25D366]" />
          </span>
          <div className="leading-tight">
            <p className="font-display text-lg">Balark Seva AI</p>
            <p className="text-[0.68rem] tracking-wide text-cream/60">
              Online • clinic assistant, Gandhinagar & Visnagar
            </p>
          </div>
        </div>

        <div ref={scrollRef} className="grid max-h-80 min-h-64 gap-3 overflow-y-auto px-4 py-4">
          {msgs.map((m, i) => (
            <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-[0.82rem] leading-relaxed ${
                  m.role === "user"
                    ? "rounded-br-sm bg-sage text-cream"
                    : "rounded-bl-sm bg-cream-deep/70 text-ink"
                }`}
              >
                <p>{m.text}</p>
                {m.doctors && m.doctors.length > 0 && (
                  <div className="mt-2.5 grid gap-2">
                    {m.doctors.map((d) => (
                      <Link
                        key={d.name}
                        href="/doctors"
                        className="flex items-center gap-2.5 rounded-xl border border-brown/15 bg-paper p-2 transition hover:border-sage"
                      >
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img
                          src={d.image}
                          alt={d.name}
                          className="h-11 w-11 rounded-full object-cover object-top"
                        />
                        <span className="leading-tight">
                          <span className="block font-display text-[0.95rem] font-bold text-brown">
                            {d.name}
                          </span>
                          <span className="block text-[0.66rem] text-ink/60">{d.qualifications}</span>
                        </span>
                      </Link>
                    ))}
                  </div>
                )}
                {m.links && m.links.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-2">
                    {m.links.map((l) => (
                      <Link
                        key={l.href + l.label}
                        href={l.href}
                        className="rounded-full bg-sage px-3 py-1.5 text-[0.7rem] font-bold text-cream transition hover:bg-sage-deep"
                      >
                        {l.label}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
          {typing && (
            <div className="flex justify-start">
              <div className="flex items-center gap-1 rounded-2xl rounded-bl-sm bg-cream-deep/70 px-4 py-3">
                <span className="typing-dot h-1.5 w-1.5 rounded-full bg-brown" />
                <span className="typing-dot h-1.5 w-1.5 rounded-full bg-brown" />
                <span className="typing-dot h-1.5 w-1.5 rounded-full bg-brown" />
              </div>
            </div>
          )}
        </div>

        <div className="flex gap-1.5 overflow-x-auto border-t border-brown/10 px-3 py-2">
          {QUICK.map((q) => (
            <button
              key={q}
              onClick={() => send(q)}
              className="rounded-full border border-sage/40 bg-cream px-3 py-1.5 text-[0.68rem] font-semibold whitespace-nowrap text-sage-deep transition hover:bg-sage hover:text-cream"
            >
              {q}
            </button>
          ))}
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            send();
          }}
          className="flex items-center gap-2 border-t border-brown/10 px-3 py-2.5"
        >
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your question…"
            className="field !py-2 text-[0.82rem]"
            aria-label="Message"
          />
          <button
            type="submit"
            aria-label="Send message"
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-sage text-cream transition hover:bg-sage-deep"
          >
            <svg viewBox="0 0 24 24" className="h-4.5 w-4.5 fill-none stroke-current" strokeWidth="2">
              <path d="M4 12l16-8-6 16-2.5-6.5L4 12z" strokeLinejoin="round" />
            </svg>
          </button>
        </form>
        <a
          href={waLink(SITE.primaryWhatsapp, "Namaste Balark Ayurveda 🙏 I was chatting with your AI assistant and want to continue on WhatsApp.")}
          target="_blank"
          rel="noreferrer"
          className="block bg-[#25D366]/10 py-2 text-center text-[0.7rem] font-bold tracking-wide text-[#128C4B] transition hover:bg-[#25D366]/20"
        >
          Continue this conversation on WhatsApp →
        </a>
      </div>
    </>
  );
}
