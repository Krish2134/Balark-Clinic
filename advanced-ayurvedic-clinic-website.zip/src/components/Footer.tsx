import Link from "next/link";
import Logo from "./Logo";
import { LOCATIONS, NAV, SITE } from "@/lib/site";

const TREATMENT_LINKS = [
  { label: "Shirodhara Therapy", href: "/treatments/shirodhara" },
  { label: "Abhyanga Massage", href: "/treatments/abhyanga" },
  { label: "Panchakarma Detox", href: "/treatments/panchakarma-detox" },
  { label: "Kati Basti (Spine Care)", href: "/treatments/kati-basti" },
  { label: "Dhruva Hair Care", href: "/treatments/hair-care" },
  { label: "All Treatments", href: "/treatments" },
];

export default function Footer() {
  return (
    <footer className="relative overflow-hidden bg-cocoa text-cream/80">
      <div className="pointer-events-none absolute -top-24 -right-24 h-72 w-72 rounded-full bg-sage/10 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-32 -left-16 h-80 w-80 rounded-full bg-gold/10 blur-3xl" />

      <div className="relative mx-auto grid max-w-7xl gap-12 px-6 py-16 md:grid-cols-2 lg:grid-cols-4">
        <div>
          <Logo tone="light" />
          <p className="mt-5 text-sm leading-relaxed text-cream/70">
            Since {SITE.since}, Balark has combined classical Panchakarma with a modern,
            diagnostic approach — treating joint, spine, skin, hair and lifestyle disorders
            from the root cause.
          </p>
          <p className="mt-4 font-display text-lg text-gold italic">“{SITE.tagline}”</p>
          <div className="mt-6 flex items-center gap-3">
            <a
              href={SITE.socials.facebook}
              target="_blank"
              rel="noreferrer"
              aria-label="Facebook"
              className="flex h-10 w-10 items-center justify-center rounded-full border border-cream/20 transition hover:border-gold hover:bg-gold hover:text-cocoa"
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4 fill-current">
                <path d="M13.5 21v-7h2.6l.4-3h-3V9.1c0-.9.3-1.5 1.6-1.5h1.5V4.9c-.3 0-1.2-.1-2.2-.1-2.2 0-3.7 1.3-3.7 3.8V11H8v3h2.7v7h2.8z" />
              </svg>
            </a>
            <a
              href={SITE.socials.instagram}
              target="_blank"
              rel="noreferrer"
              aria-label="Instagram"
              className="flex h-10 w-10 items-center justify-center rounded-full border border-cream/20 transition hover:border-gold hover:bg-gold hover:text-cocoa"
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4 fill-none stroke-current" strokeWidth="2">
                <rect x="3.5" y="3.5" width="17" height="17" rx="4.5" />
                <circle cx="12" cy="12" r="3.6" />
                <circle cx="17.2" cy="6.8" r="1.1" fill="currentColor" stroke="none" />
              </svg>
            </a>
            <a
              href={`https://wa.me/${SITE.primaryWhatsapp}`}
              target="_blank"
              rel="noreferrer"
              aria-label="WhatsApp"
              className="flex h-10 w-10 items-center justify-center rounded-full border border-cream/20 transition hover:border-[#25D366] hover:bg-[#25D366] hover:text-cocoa"
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4 fill-current">
                <path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5.1-1.3A10 10 0 1 0 12 2zm5.4 14.1c-.2.7-1.3 1.3-1.9 1.4-.5.1-1.1.1-1.8-.1-.4-.1-1-.3-1.7-.6-3-1.3-4.9-4.3-5.1-4.5-.1-.2-1.2-1.6-1.2-3.1s.8-2.2 1-2.5c.3-.3.6-.4.8-.4h.6c.2 0 .4 0 .6.5s.8 1.9.8 2c.1.1.1.3 0 .5-.3.6-.7.9-.5 1.2.7 1.2 1.6 2 2.8 2.6.3.2.5.1.7-.1l.9-1c.2-.3.4-.2.7-.1l2 1c.3.1.5.2.6.4 0 .1 0 .7-.3 1.3z" />
              </svg>
            </a>
          </div>
        </div>

        <div>
          <h3 className="font-display text-xl text-cream">Quick Links</h3>
          <ul className="mt-5 grid gap-2.5 text-sm">
            {NAV.map((n) => (
              <li key={n.href}>
                <Link href={n.href} className="group inline-flex items-center gap-2 transition hover:text-gold">
                  <span className="h-px w-3 bg-gold/60 transition-all group-hover:w-5" />
                  {n.label}
                </Link>
              </li>
            ))}
            <li>
              <Link href="/admin" className="group inline-flex items-center gap-2 transition hover:text-gold">
                <span className="h-px w-3 bg-gold/60 transition-all group-hover:w-5" />
                Doctor Dashboard
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h3 className="font-display text-xl text-cream">Signature Therapies</h3>
          <ul className="mt-5 grid gap-2.5 text-sm">
            {TREATMENT_LINKS.map((t) => (
              <li key={t.href}>
                <Link href={t.href} className="group inline-flex items-center gap-2 transition hover:text-gold">
                  <span className="h-px w-3 bg-gold/60 transition-all group-hover:w-5" />
                  {t.label}
                </Link>
              </li>
            ))}
          </ul>
          <p className="mt-5 inline-flex items-center gap-2 rounded-full border border-gold/40 bg-gold/10 px-3 py-1.5 text-[0.7rem] font-bold tracking-wider text-gold uppercase">
            <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 fill-none stroke-current" strokeWidth="2">
              <rect x="3" y="10" width="18" height="10" rx="2" />
              <path d="M8 10V7a4 4 0 0 1 8 0v3" />
            </svg>
            Online payment — coming soon
          </p>
        </div>

        <div>
          <h3 className="font-display text-xl text-cream">Our Clinics</h3>
          <ul className="mt-5 grid gap-5 text-sm">
            {LOCATIONS.map((l) => (
              <li key={l.key}>
                <p className="font-bold text-cream">{l.name}</p>
                <p className="mt-1 text-cream/65">{l.address}</p>
                <a href={l.directions} target="_blank" rel="noreferrer" className="mt-1 inline-block text-gold underline-offset-4 hover:underline">
                  Get directions →
                </a>
              </li>
            ))}
          </ul>
          <p className="mt-5 text-sm">
            {SITE.phones.map((p) => (
              <a key={p.href} href={p.href} className="block transition hover:text-gold">
                {p.label}
              </a>
            ))}
            <a href={`mailto:${SITE.emails.general}`} className="transition hover:text-gold">
              {SITE.emails.general}
            </a>
          </p>
        </div>
      </div>

      <div className="relative border-t border-cream/10">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-6 py-5 text-[0.72rem] tracking-wide text-cream/50 md:flex-row">
          <p>© {new Date().getFullYear()} {SITE.name}. All rights reserved.</p>
          <p>
            WordPress blog & WooCommerce store integration ready • Payment gateway on the roadmap
          </p>
        </div>
      </div>
    </footer>
  );
}
