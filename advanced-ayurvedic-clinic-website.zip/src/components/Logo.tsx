import { SITE } from "@/lib/site";

export function LogoMark({ className = "h-12 w-12" }: { className?: string }) {
  return (
    <svg viewBox="0 0 120 120" className={className} aria-hidden="true">
      {/* wheat sprig */}
      <path
        d="M84 16c11 7 17 18 17 31"
        fill="none"
        stroke="#C9973B"
        strokeWidth="4"
        strokeLinecap="round"
      />
      <ellipse cx="88" cy="21" rx="6" ry="3.2" fill="#C9973B" transform="rotate(-30 88 21)" />
      <ellipse cx="95" cy="29" rx="6" ry="3.2" fill="#C9973B" transform="rotate(-24 95 29)" />
      <ellipse cx="99" cy="38" rx="6" ry="3.2" fill="#C9973B" transform="rotate(-14 99 38)" />
      {/* flower bud */}
      <path d="M56 26c5 4 6.6 10.6 3.8 16.8-5.8-2.8-8.4-10.6-3.8-16.8z" fill="#E8722A" />
      {/* leaves */}
      <path d="M42 38c11.6 6 15.6 19 9 30.4C39.4 63.4 34.2 49 42 38z" fill="#2E8B62" />
      <path d="M66 40c-9.8 6-13 17.8-7 27.6 10.6-4 14.8-17 7-27.6z" fill="#45A578" />
      {/* pestle */}
      <path d="M76 62l17-17" stroke="#6B4444" strokeWidth="8" strokeLinecap="round" />
      <circle cx="96" cy="42" r="6.4" fill="none" stroke="#6B4444" strokeWidth="5" />
      {/* mortar */}
      <path d="M20 62h80c0 24-17.2 40-40 40S20 86 20 62z" fill="#6B4444" />
      <circle cx="60" cy="80" r="14.5" fill="#C9973B" />
      <path d="M60 72.6c3.6 3.2 4.4 8.6 2 13.2-4.4-2-6.4-8.6-2-13.2z" fill="#3B241F" />
      <rect x="48" y="104" width="24" height="6" rx="3" fill="#4A2B26" />
    </svg>
  );
}

export default function Logo({
  tone = "dark",
  compact = false,
}: {
  tone?: "dark" | "light";
  compact?: boolean;
}) {
  const word = tone === "light" ? "text-cream" : "text-brown";
  const sub = tone === "light" ? "text-cream/70" : "text-brown/70";
  return (
    <span className="flex items-center gap-3">
      <LogoMark className={compact ? "h-10 w-10" : "h-12 w-12"} />
      <span className="leading-none">
        <span
          className={`block font-body text-[1.35rem] font-extrabold tracking-[0.08em] ${word}`}
        >
          {SITE.shortName}
        </span>
        <span
          className={`mt-1 block font-body text-[0.52rem] font-bold tracking-[0.24em] uppercase ${sub}`}
        >
          {SITE.sub}
        </span>
      </span>
    </span>
  );
}
