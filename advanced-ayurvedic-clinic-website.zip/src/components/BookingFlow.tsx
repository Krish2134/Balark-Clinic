"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import type { Doctor, Treatment } from "@/db/schema";
import { LOCATIONS, TIME_SLOTS, SITE } from "@/lib/site";

type Notif = { channel: string; recipient: string; status: string };
type Result = {
  code: string;
  doctorName: string;
  location: string;
  date: string;
  timeSlot: string;
  notifications: Notif[];
  whatsappLink: string;
};

const STEPS = ["Choose doctor", "Pick schedule", "Your details"];

function todayISO() {
  const d = new Date();
  return d.toISOString().slice(0, 10);
}
function maxISO() {
  const d = new Date();
  d.setDate(d.getDate() + 60);
  return d.toISOString().slice(0, 10);
}
function prettyDate(iso: string) {
  if (!iso) return "";
  const d = new Date(`${iso}T00:00:00`);
  return d.toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
}

export default function BookingFlow({
  doctors,
  treatments,
  initialDoctor,
  initialTreatment,
}: {
  doctors: Doctor[];
  treatments: Treatment[];
  initialDoctor?: string;
  initialTreatment?: string;
}) {
  const [step, setStep] = useState(0);
  const [doctorSlug, setDoctorSlug] = useState(initialDoctor ?? "");
  const [location, setLocation] = useState(LOCATIONS[0].name);
  const [date, setDate] = useState("");
  const [slot, setSlot] = useState("");
  const [booked, setBooked] = useState<string[]>([]);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [treatmentSlug, setTreatmentSlug] = useState(initialTreatment ?? "");
  const [reason, setReason] = useState("");
  const [consent, setConsent] = useState(false);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<Result | null>(null);

  const doctor = doctors.find((d) => d.slug === doctorSlug);

  useEffect(() => {
    if (!doctorSlug || !date) {
      setBooked([]);
      return;
    }
    let alive = true;
    setLoadingSlots(true);
    fetch(`/api/appointments?doctor=${doctorSlug}&date=${date}`)
      .then((r) => r.json())
      .then((d) => alive && setBooked(d.bookedSlots ?? []))
      .catch(() => alive && setBooked([]))
      .finally(() => alive && setLoadingSlots(false));
    return () => {
      alive = false;
    };
  }, [doctorSlug, date]);

  const canNext = useMemo(() => {
    if (step === 0) return !!doctorSlug;
    if (step === 1) return !!date && !!slot;
    return name.trim().length >= 3 && /^[6-9]\d{9}$/.test(phone.replace(/\D/g, "").slice(-10)) && reason.trim().length >= 8 && consent;
  }, [step, doctorSlug, date, slot, name, phone, reason, consent]);

  async function submit() {
    setError("");
    setSubmitting(true);
    try {
      const res = await fetch("/api/appointments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ doctorSlug, location, date, timeSlot: slot, patientName: name, phone, email, treatmentSlug: treatmentSlug || null, reason }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Could not book right now.");
      setResult(data);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong.");
    } finally {
      setSubmitting(false);
    }
  }

  if (result) {
    return (
      <div className="mx-auto max-w-2xl rounded-3xl border border-sage/40 bg-paper p-10 text-center shadow-[0_30px_60px_-30px_rgba(63,107,71,0.5)]">
        <span className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-sage/15">
          <svg viewBox="0 0 24 24" className="h-10 w-10 fill-none stroke-sage" strokeWidth="2.4">
            <path d="M4 12.5l5 5L20 6.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </span>
        <h2 className="mt-6 font-display text-4xl font-semibold text-brown-deep">Appointment requested!</h2>
        <p className="mt-3 text-ink/70">
          Reference <strong className="font-bold text-sage-deep">{result.code}</strong> — {result.doctorName} at{" "}
          {result.location}, {prettyDate(result.date)} at {result.timeSlot}.
        </p>

        <div className="mt-7 rounded-2xl border border-brown/12 bg-cream-deep/50 p-5 text-left">
          <p className="text-[0.68rem] font-bold tracking-[0.18em] text-ink/55 uppercase">Doctor notified instantly</p>
          <ul className="mt-3 grid gap-2.5">
            {result.notifications.map((n, i) => (
              <li key={i} className="flex items-center justify-between gap-3 text-sm">
                <span className="flex items-center gap-2.5 text-ink/80">
                  {n.channel === "email" ? (
                    <svg viewBox="0 0 24 24" className="h-4.5 w-4.5 fill-none stroke-sage-deep" strokeWidth="2">
                      <rect x="3" y="5" width="18" height="14" rx="2.5" />
                      <path d="M3.5 7l8.5 6 8.5-6" />
                    </svg>
                  ) : (
                    <svg viewBox="0 0 24 24" className="h-4.5 w-4.5 fill-[#128C4B]">
                      <path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5.1-1.3A10 10 0 1 0 12 2zm5.4 14.1c-.2.7-1.3 1.3-1.9 1.4-.5.1-1.1.1-1.8-.1-.4-.1-1-.3-1.7-.6-3-1.3-4.9-4.3-5.1-4.5-.1-.2-1.2-1.6-1.2-3.1s.8-2.2 1-2.5c.3-.3.6-.4.8-.4h.6c.2 0 .4 0 .6.5s.8 1.9.8 2c.1.1.1.3 0 .5-.3.6-.7.9-.5 1.2.7 1.2 1.6 2 2.8 2.6.3.2.5.1.7-.1l.9-1c.2-.3.4-.2.7-.1l2 1c.3.1.5.2.6.4 0 .1 0 .7-.3 1.3z" />
                    </svg>
                  )}
                  {n.channel === "email" ? `Email → ${n.recipient}` : `WhatsApp → ${n.recipient}`}
                </span>
                <span
                  className={`rounded-full px-3 py-1 text-[0.62rem] font-extrabold tracking-wider uppercase ${
                    n.status === "sent" ? "bg-sage/15 text-sage-deep" : "bg-gold/20 text-gold"
                  }`}
                >
                  {n.status === "sent" ? "Delivered" : "Queued for delivery"}
                </span>
              </li>
            ))}
          </ul>
          <p className="mt-4 text-[0.78rem] leading-relaxed text-ink/60">
            The clinic will call you to confirm. Tap below to send your reference to the clinic
            WhatsApp so your slot is held immediately.
          </p>
        </div>

        <div className="mt-7 flex flex-wrap justify-center gap-4">
          <a href={result.whatsappLink} target="_blank" rel="noreferrer" className="rounded-full bg-[#25D366] px-7 py-3.5 text-sm font-bold text-white transition hover:-translate-y-0.5 hover:brightness-95">
            Confirm on WhatsApp
          </a>
          <button onClick={() => { setResult(null); setStep(0); setSlot(""); }} className="rounded-full border-2 border-brown/25 px-7 py-3.5 text-sm font-bold text-brown transition hover:-translate-y-0.5 hover:border-sage hover:text-sage-deep">
            Book another appointment
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="grid gap-10 lg:grid-cols-[1.35fr_0.65fr]">
      <div>
        {/* stepper */}
        <ol className="mb-10 flex items-center gap-3">
          {STEPS.map((s, i) => (
            <li key={s} className="flex flex-1 items-center gap-3">
              <button
                onClick={() => i < step && setStep(i)}
                className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full font-display text-lg font-bold transition ${
                  i === step ? "bg-sage text-cream shadow-lg" : i < step ? "bg-sage/20 text-sage-deep" : "bg-brown/10 text-brown/50"
                }`}
                aria-current={i === step ? "step" : undefined}
              >
                {i < step ? "✓" : i + 1}
              </button>
              <span className={`hidden text-[0.78rem] font-bold tracking-wide sm:block ${i === step ? "text-sage-deep" : "text-ink/50"}`}>{s}</span>
              {i < STEPS.length - 1 && <span className={`h-px flex-1 ${i < step ? "bg-sage" : "bg-brown/15"}`} />}
            </li>
          ))}
        </ol>

        {step === 0 && (
          <div className="grid gap-5 sm:grid-cols-2">
            {doctors.map((d) => (
              <button
                key={d.slug}
                onClick={() => setDoctorSlug(d.slug)}
                className={`card-lift overflow-hidden rounded-2xl border-2 text-left transition ${
                  doctorSlug === d.slug ? "border-sage shadow-[0_20px_40px_-20px_rgba(63,107,71,0.6)]" : "border-transparent bg-paper"
                } bg-paper`}
              >
                <div className="relative h-56 overflow-hidden">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={d.image} alt={d.name} className="h-full w-full object-cover object-top" />
                  {doctorSlug === d.slug && (
                    <span className="absolute top-3 right-3 flex h-8 w-8 items-center justify-center rounded-full bg-sage text-cream shadow">
                      <svg viewBox="0 0 24 24" className="h-4 w-4 fill-none stroke-current" strokeWidth="3">
                        <path d="M5 13l4 4L19 7" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </span>
                  )}
                </div>
                <div className="p-5">
                  <h3 className="font-display text-2xl font-semibold text-brown">{d.name}</h3>
                  <p className="mt-0.5 text-[0.68rem] font-bold tracking-[0.14em] text-gold uppercase">{d.qualifications}</p>
                  <p className="mt-2 text-[0.82rem] text-ink/65">{d.role}</p>
                </div>
              </button>
            ))}
          </div>
        )}

        {step === 1 && (
          <div className="space-y-8">
            <div>
              <p className="mb-3 text-[0.72rem] font-bold tracking-[0.18em] text-ink/55 uppercase">1 • Clinic branch</p>
              <div className="grid gap-4 sm:grid-cols-2">
                {LOCATIONS.map((l) => (
                  <button
                    key={l.key}
                    onClick={() => setLocation(l.name)}
                    className={`rounded-2xl border-2 p-5 text-left transition ${
                      location === l.name ? "border-sage bg-sage/8" : "border-brown/15 bg-paper hover:border-sage/50"
                    }`}
                  >
                    <p className="font-display text-xl font-semibold text-brown">{l.name}</p>
                    <p className="mt-1 text-[0.8rem] text-ink/65">{l.address}</p>
                  </button>
                ))}
              </div>
            </div>
            <div>
              <p className="mb-3 text-[0.72rem] font-bold tracking-[0.18em] text-ink/55 uppercase">2 • Date</p>
              <input type="date" min={todayISO()} max={maxISO()} value={date} onChange={(e) => { setDate(e.target.value); setSlot(""); }} className="field max-w-xs" />
              <p className="mt-2 text-[0.72rem] text-ink/55">Sunday slots are by prior appointment — the clinic will call to confirm.</p>
            </div>
            <div>
              <p className="mb-3 text-[0.72rem] font-bold tracking-[0.18em] text-ink/55 uppercase">3 • Time slot {loadingSlots && "(checking availability…)"}</p>
              {!date ? (
                <p className="rounded-xl border border-dashed border-brown/25 bg-paper p-5 text-sm text-ink/55">Pick a date to see live slot availability.</p>
              ) : (
                <div className="grid grid-cols-3 gap-3 sm:grid-cols-4">
                  {TIME_SLOTS.map((s) => {
                    const taken = booked.includes(s);
                    return (
                      <button
                        key={s}
                        disabled={taken || loadingSlots}
                        onClick={() => setSlot(s)}
                        className={`rounded-xl border px-3 py-2.5 text-[0.78rem] font-bold transition ${
                          taken
                            ? "cursor-not-allowed border-brown/10 bg-brown/5 text-brown/35 line-through"
                            : slot === s
                              ? "border-sage bg-sage text-cream shadow"
                              : "border-brown/20 bg-paper text-brown hover:border-sage hover:text-sage-deep"
                        }`}
                      >
                        {s}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="grid gap-5 rounded-2xl border border-brown/12 bg-paper p-7 sm:grid-cols-2">
            <label className="grid gap-1.5 text-[0.75rem] font-bold tracking-wide text-ink/60">
              Full name *
              <input value={name} onChange={(e) => setName(e.target.value)} className="field" placeholder="e.g. Ramesh Patel" />
            </label>
            <label className="grid gap-1.5 text-[0.75rem] font-bold tracking-wide text-ink/60">
              Mobile number *
              <input value={phone} onChange={(e) => setPhone(e.target.value)} className="field" placeholder="10-digit mobile" inputMode="numeric" />
            </label>
            <label className="grid gap-1.5 text-[0.75rem] font-bold tracking-wide text-ink/60 sm:col-span-2">
              Email (optional — for your appointment receipt)
              <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="field" placeholder="you@example.com" />
            </label>
            <label className="grid gap-1.5 text-[0.75rem] font-bold tracking-wide text-ink/60 sm:col-span-2">
              Preferred treatment (optional)
              <select value={treatmentSlug} onChange={(e) => setTreatmentSlug(e.target.value)} className="field">
                <option value="">Not sure — doctor will advise</option>
                {treatments.map((t) => (
                  <option key={t.slug} value={t.slug}>{t.name}</option>
                ))}
              </select>
            </label>
            <label className="grid gap-1.5 text-[0.75rem] font-bold tracking-wide text-ink/60 sm:col-span-2">
              Reason for visit *
              <textarea value={reason} onChange={(e) => setReason(e.target.value)} rows={4} className="field resize-none" placeholder="Describe your complaint, since when, and any reports or medicines…" />
            </label>
            <label className="flex items-start gap-3 text-[0.8rem] text-ink/70 sm:col-span-2">
              <input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} className="mt-0.5 h-4.5 w-4.5 accent-sage" />
              I agree that Balark Clinic may contact me on WhatsApp / call / email about this appointment, and alert my chosen doctor with these booking details. *
            </label>
          </div>
        )}

        {error && <p className="mt-6 rounded-xl border border-flame/40 bg-flame/10 px-5 py-3 text-sm font-semibold text-flame">{error}</p>}

        <div className="mt-8 flex items-center gap-4">
          {step > 0 && (
            <button onClick={() => setStep(step - 1)} className="rounded-full border-2 border-brown/25 px-6 py-3 text-sm font-bold text-brown transition hover:border-brown">
              ← Back
            </button>
          )}
          {step < 2 ? (
            <button
              disabled={!canNext}
              onClick={() => setStep(step + 1)}
              className={`rounded-full px-8 py-3.5 text-sm font-bold tracking-wide transition ${
                canNext ? "bg-sage text-cream shadow-lg hover:-translate-y-0.5 hover:bg-sage-deep" : "cursor-not-allowed bg-brown/15 text-brown/40"
              }`}
            >
              Continue →
            </button>
          ) : (
            <button
              disabled={!canNext || submitting}
              onClick={submit}
              className={`rounded-full px-8 py-3.5 text-sm font-bold tracking-wide transition ${
                canNext && !submitting ? "bg-sage text-cream shadow-lg hover:-translate-y-0.5 hover:bg-sage-deep" : "cursor-not-allowed bg-brown/15 text-brown/40"
              }`}
            >
              {submitting ? "Booking…" : "Confirm appointment"}
            </button>
          )}
        </div>
      </div>

      {/* summary rail */}
      <aside className="lg:sticky lg:top-32 lg:self-start">
        <div className="rounded-2xl border border-brown/12 bg-cocoa p-6 text-cream">
          <p className="text-[0.66rem] font-bold tracking-[0.2em] text-gold uppercase">Your appointment</p>
          <dl className="mt-4 space-y-3.5 text-sm">
            <div>
              <dt className="text-cream/50">Doctor</dt>
              <dd className="font-display text-lg font-semibold">{doctor ? doctor.name : "—"}</dd>
              {doctor && <dd className="text-[0.7rem] text-gold">{doctor.qualifications}</dd>}
            </div>
            <div>
              <dt className="text-cream/50">Branch</dt>
              <dd className="font-semibold">{location}</dd>
            </div>
            <div>
              <dt className="text-cream/50">Date & time</dt>
              <dd className="font-semibold">{date ? prettyDate(date) : "—"}{slot ? ` • ${slot}` : ""}</dd>
            </div>
            <div>
              <dt className="text-cream/50">Payment</dt>
              <dd className="text-[0.8rem] text-cream/75">Pay at clinic • online payments coming soon</dd>
            </div>
          </dl>
          <div className="mt-5 border-t border-cream/15 pt-4 text-[0.78rem] leading-relaxed text-cream/70">
            On confirm, <strong className="text-cream">{doctor ? doctor.name : "your doctor"}</strong> receives an
            instant <strong className="text-cream">email + WhatsApp</strong> alert with your name, slot and reason.
          </div>
          <a href={`tel:${SITE.phones[0].href.replace("tel:", "")}`} className="mt-4 block rounded-full border border-cream/30 py-2.5 text-center text-[0.75rem] font-bold transition hover:border-gold hover:text-gold">
            Prefer calling? {SITE.phones[0].label}
          </a>
        </div>
        <p className="mt-4 text-center text-[0.72rem] text-ink/55">
          Need help? <Link href="/contact" className="font-bold text-sage-deep underline-offset-4 hover:underline">Contact the clinic</Link>
        </p>
      </aside>
    </div>
  );
}
