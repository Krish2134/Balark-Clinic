"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import Logo from "./Logo";
import { NAV, SITE } from "@/lib/site";

export default function Header() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => setOpen(false), [pathname]);

  return (
    <header className="sticky top-0 z-50">
      {/* top info bar */}
      <div className="hidden bg-cocoa text-cream/85 md:block">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-6 px-6 py-1.5 text-[0.72rem] tracking-wide">
          <p className="flex items-center gap-4">
            <span className="inline-flex items-center gap-1.5">
              <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 fill-none stroke-gold" strokeWidth="2">
                <circle cx="12" cy="12" r="9" />
                <path d="M12 7v5l3 2" strokeLinecap="round" />
              </svg>
              Mon–Sat 9 AM – 1 PM • 4 PM – 8 PM
            </span>
            <span className="text-cream/50">|</span>
            <span>Gandhinagar & Visnagar, Gujarat</span>
          </p>
          <p className="flex items-center gap-4">
            <a href={SITE.phones[0].href} className="transition hover:text-gold">
              {SITE.phones[0].label}
            </a>
            <a
              href={SITE.socials.facebook}
              target="_blank"
              rel="noreferrer"
              aria-label="Facebook"
              className="transition hover:text-gold"
            >
              <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 fill-current">
                <path d="M13.5 21v-7h2.6l.4-3h-3V9.1c0-.9.3-1.5 1.6-1.5h1.5V4.9c-.3 0-1.2-.1-2.2-.1-2.2 0-3.7 1.3-3.7 3.8V11H8v3h2.7v7h2.8z" />
              </svg>
            </a>
            <a
              href={SITE.socials.instagram}
              target="_blank"
              rel="noreferrer"
              aria-label="Instagram"
              className="transition hover:text-gold"
            >
              <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 fill-none stroke-current" strokeWidth="2">
                <rect x="3.5" y="3.5" width="17" height="17" rx="4.5" />
                <circle cx="12" cy="12" r="3.6" />
                <circle cx="17.2" cy="6.8" r="1.1" fill="currentColor" stroke="none" />
              </svg>
            </a>
          </p>
        </div>
      </div>

      {/* main bar */}
      <div
        className={`border-b border-brown/10 transition-all duration-300 ${
          scrolled ? "bg-cream/95 shadow-[0_10px_30px_-18px_rgba(59,36,31,0.4)] backdrop-blur" : "bg-cream"
        }`}
      >
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-6 px-6 py-3">
          <Link href="/" aria-label="Balark Ayurveda home">
            <Logo />
          </Link>

          <nav className="hidden items-center gap-1 lg:flex">
            {NAV.map((item) => {
              const active =
                item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`relative rounded-full px-3.5 py-2 text-[0.82rem] font-semibold tracking-wide transition ${
                    active ? "text-sage-deep" : "text-ink/70 hover:text-sage-deep"
                  }`}
                >
                  {item.label}
                  <span
                    className={`absolute inset-x-3.5 -bottom-0.5 h-[2px] rounded-full bg-gold transition-transform duration-300 ${
                      active ? "scale-x-100" : "scale-x-0"
                    }`}
                  />
                </Link>
              );
            })}
          </nav>

          <div className="flex items-center gap-3">
            <Link
              href="/book"
              className="hidden rounded-full bg-sage px-5 py-2.5 text-[0.82rem] font-bold tracking-wide text-cream shadow-[0_10px_24px_-12px_rgba(63,107,71,0.9)] transition hover:-translate-y-0.5 hover:bg-sage-deep sm:inline-block"
            >
              Book Appointment
            </Link>
            <button
              onClick={() => setOpen((v) => !v)}
              aria-label="Toggle menu"
              aria-expanded={open}
              className="flex h-10 w-10 flex-col items-center justify-center gap-[5px] rounded-full border border-brown/20 bg-paper lg:hidden"
            >
              <span
                className={`h-[2px] w-4.5 bg-brown transition-transform ${open ? "translate-y-[7px] rotate-45" : ""}`}
              />
              <span className={`h-[2px] w-4.5 bg-brown transition-opacity ${open ? "opacity-0" : ""}`} />
              <span
                className={`h-[2px] w-4.5 bg-brown transition-transform ${open ? "-translate-y-[7px] -rotate-45" : ""}`}
              />
            </button>
          </div>
        </div>

        {/* mobile menu */}
        <div
          className={`overflow-hidden border-t border-brown/10 bg-paper transition-[max-height] duration-500 lg:hidden ${
            open ? "max-h-[26rem]" : "max-h-0"
          }`}
        >
          <nav className="mx-auto grid max-w-7xl gap-1 px-6 py-4">
            {NAV.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="rounded-lg px-3 py-2.5 text-sm font-semibold text-ink/80 transition hover:bg-cream-deep hover:text-sage-deep"
              >
                {item.label}
              </Link>
            ))}
            <Link
              href="/book"
              className="mt-2 rounded-full bg-sage px-5 py-3 text-center text-sm font-bold text-cream"
            >
              Book Appointment
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
}
