"use client";

import { useState } from "react";
import { SITE, waLink } from "@/lib/site";

export default function ContactForm() {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [topic, setTopic] = useState("Appointment enquiry");
  const [message, setMessage] = useState("");

  function sendWhatsApp(e: React.FormEvent) {
    e.preventDefault();
    const text = `Namaste Balark Ayurveda 🙏%0AName: ${name}%0APhone: ${phone}%0ATopic: ${topic}%0AMessage: ${message}`;
    window.open(`https://wa.me/${SITE.primaryWhatsapp}?text=${text}`, "_blank");
  }

  return (
    <form onSubmit={sendWhatsApp} className="grid gap-4 rounded-2xl border border-brown/12 bg-paper p-7 sm:grid-cols-2">
      <label className="grid gap-1.5 text-[0.72rem] font-bold tracking-wide text-ink/60">
        Name *
        <input required value={name} onChange={(e) => setName(e.target.value)} className="field" placeholder="Your name" />
      </label>
      <label className="grid gap-1.5 text-[0.72rem] font-bold tracking-wide text-ink/60">
        Mobile *
        <input required value={phone} onChange={(e) => setPhone(e.target.value)} className="field" placeholder="10-digit mobile" inputMode="numeric" />
      </label>
      <label className="grid gap-1.5 text-[0.72rem] font-bold tracking-wide text-ink/60 sm:col-span-2">
        Topic
        <select value={topic} onChange={(e) => setTopic(e.target.value)} className="field">
          <option>Appointment enquiry</option>
          <option>Treatment guidance</option>
          <option>Request a new therapy</option>
          <option>Hair & skin products (Dhruva range)</option>
          <option>Online consultation</option>
          <option>Other</option>
        </select>
      </label>
      <label className="grid gap-1.5 text-[0.72rem] font-bold tracking-wide text-ink/60 sm:col-span-2">
        Message *
        <textarea required rows={4} value={message} onChange={(e) => setMessage(e.target.value)} className="field resize-none" placeholder="Write your question or describe your condition…" />
      </label>
      <div className="flex flex-wrap gap-3 sm:col-span-2">
        <button type="submit" className="rounded-full bg-[#25D366] px-7 py-3.5 text-sm font-bold text-white transition hover:-translate-y-0.5 hover:brightness-95">
          Send via WhatsApp
        </button>
        <a href={`mailto:${SITE.emails.general}?subject=${encodeURIComponent("Enquiry from website")}&body=${encodeURIComponent(`Name: ${name}\nPhone: ${phone}\n${message}`)}`} className="rounded-full border-2 border-brown/25 px-7 py-3.5 text-sm font-bold text-brown transition hover:-translate-y-0.5 hover:border-gold hover:text-gold">
          Send via Email
        </a>
      </div>
    </form>
  );
}
