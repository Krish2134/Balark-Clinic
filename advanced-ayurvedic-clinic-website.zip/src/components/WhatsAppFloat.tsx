"use client";

import { useState } from "react";
import { SITE, WA_DEFAULT_MSG, waLink } from "@/lib/site";

export default function WhatsAppFloat() {
  const [hover, setHover] = useState(false);
  return (
    <a
      href={waLink(SITE.primaryWhatsapp, WA_DEFAULT_MSG)}
      target="_blank"
      rel="noreferrer"
      aria-label="Chat with Balark Clinic on WhatsApp"
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      className="anim-pulse-ring group fixed right-5 bottom-5 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] text-white shadow-[0_16px_32px_-12px_rgba(37,211,102,0.7)] transition-transform hover:scale-110"
    >
      <svg viewBox="0 0 24 24" className="h-7 w-7 fill-current">
        <path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5.1-1.3A10 10 0 1 0 12 2zm5.4 14.1c-.2.7-1.3 1.3-1.9 1.4-.5.1-1.1.1-1.8-.1-.4-.1-1-.3-1.7-.6-3-1.3-4.9-4.3-5.1-4.5-.1-.2-1.2-1.6-1.2-3.1s.8-2.2 1-2.5c.3-.3.6-.4.8-.4h.6c.2 0 .4 0 .6.5s.8 1.9.8 2c.1.1.1.3 0 .5-.3.6-.7.9-.5 1.2.7 1.2 1.6 2 2.8 2.6.3.2.5.1.7-.1l.9-1c.2-.3.4-.2.7-.1l2 1c.3.1.5.2.6.4 0 .1 0 .7-.3 1.3z" />
      </svg>
      <span
        className={`pointer-events-none absolute right-16 rounded-full bg-cocoa px-4 py-2 text-xs font-semibold whitespace-nowrap text-cream shadow-lg transition-all duration-300 ${
          hover ? "translate-x-0 opacity-100" : "translate-x-2 opacity-0"
        }`}
      >
        Chat on WhatsApp • replies in minutes
      </span>
    </a>
  );
}
