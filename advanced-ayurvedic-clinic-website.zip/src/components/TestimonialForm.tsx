"use client";

import { useState } from "react";
import Stars from "./Stars";

const TREATMENTS = [
  "Shirodhara Therapy",
  "Abhyanga Massage",
  "Panchakarma Detox",
  "Kati Basti",
  "Janu Basti",
  "Ayurvedic Facial",
  "Dhruva Hair Care",
  "Nasya Karma",
  "General Consultation",
];

export default function TestimonialForm() {
  const [name, setName] = useState("");
  const [location, setLocation] = useState("");
  const [rating, setRating] = useState(5);
  const [treatment, setTreatment] = useState(TREATMENTS[0]);
  const [body, setBody] = useState("");
  const [state, setState] = useState<"idle" | "sending" | "done" | "error">("idle");

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setState("sending");
    try {
      const res = await fetch("/api/testimonials", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, location, rating, treatment, body }),
      });
      if (!res.ok) throw new Error();
      setState("done");
      setName(""); setLocation(""); setBody(""); setRating(5);
    } catch {
      setState("error");
    }
  }

  if (state === "done") {
    return (
      <div className="rounded-2xl border border-sage/40 bg-sage/10 p-8 text-center">
        <p className="font-display text-2xl font-semibold text-sage-deep">Thank you for your words 🙏</p>
        <p className="mt-2 text-sm text-ink/70">
          Your review has been submitted and will appear on the website once the clinic approves it.
        </p>
        <button onClick={() => setState("idle")} className="mt-5 rounded-full border-2 border-sage/50 px-6 py-2.5 text-sm font-bold text-sage-deep transition hover:bg-sage hover:text-cream">
          Write another review
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="grid gap-4 rounded-2xl border border-brown/12 bg-paper p-7 sm:grid-cols-2">
      <label className="grid gap-1.5 text-[0.72rem] font-bold tracking-wide text-ink/60">
        Your name *
        <input required value={name} onChange={(e) => setName(e.target.value)} className="field" placeholder="Full name" />
      </label>
      <label className="grid gap-1.5 text-[0.72rem] font-bold tracking-wide text-ink/60">
        City / village *
        <input required value={location} onChange={(e) => setLocation(e.target.value)} className="field" placeholder="e.g. Gandhinagar" />
      </label>
      <label className="grid gap-1.5 text-[0.72rem] font-bold tracking-wide text-ink/60">
        Treatment received
        <select value={treatment} onChange={(e) => setTreatment(e.target.value)} className="field">
          {TREATMENTS.map((t) => (
            <option key={t}>{t}</option>
          ))}
        </select>
      </label>
      <div className="grid gap-1.5 text-[0.72rem] font-bold tracking-wide text-ink/60">
        Your rating
        <div className="flex items-center gap-2 pt-1.5">
          {[1, 2, 3, 4, 5].map((i) => (
            <button key={i} type="button" onClick={() => setRating(i)} aria-label={`${i} stars`} className="transition hover:scale-110">
              <Stars rating={i <= rating ? 5 : 0} className="h-6 w-6" />
            </button>
          ))}
        </div>
      </div>
      <label className="grid gap-1.5 text-[0.72rem] font-bold tracking-wide text-ink/60 sm:col-span-2">
        Your experience *
        <textarea required rows={4} value={body} onChange={(e) => setBody(e.target.value)} className="field resize-none" placeholder="How did your treatment go? What changed for you?" />
      </label>
      <div className="sm:col-span-2">
        <button type="submit" disabled={state === "sending"} className="rounded-full bg-sage px-8 py-3.5 text-sm font-bold text-cream transition hover:-translate-y-0.5 hover:bg-sage-deep disabled:opacity-60">
          {state === "sending" ? "Submitting…" : "Submit review"}
        </button>
        {state === "error" && <p className="mt-3 text-sm font-semibold text-flame">Could not submit. Please try again or share your review on WhatsApp.</p>}
      </div>
    </form>
  );
}
