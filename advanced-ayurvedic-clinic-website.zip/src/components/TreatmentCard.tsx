import Link from "next/link";
import type { Treatment } from "@/db/schema";

export default function TreatmentCard({ t }: { t: Treatment }) {
  return (
    <article className="card-lift group flex flex-col overflow-hidden rounded-2xl border border-brown/12 bg-paper shadow-[0_10px_30px_-18px_rgba(59,36,31,0.35)]">
      <div className="relative h-52 overflow-hidden">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={t.image}
          alt={t.name}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-[1200ms] group-hover:scale-110"
        />
        <span className="absolute top-3 left-3 rounded-full bg-cream/90 px-3 py-1 text-[0.62rem] font-bold tracking-[0.14em] text-sage-deep uppercase backdrop-blur">
          {t.category}
        </span>
        <span className="absolute right-3 bottom-3 rounded-full bg-cocoa/80 px-3 py-1 text-[0.65rem] font-semibold text-cream backdrop-blur">
          {t.duration}
        </span>
      </div>
      <div className="flex flex-1 flex-col p-5">
        <h3 className="font-display text-2xl font-semibold text-brown">{t.name}</h3>
        <p className="mt-2 flex-1 text-sm leading-relaxed text-ink/70">{t.tagline}</p>
        <div className="mt-5 flex items-center justify-between gap-3 border-t border-brown/10 pt-4">
          <Link
            href={`/book?treatment=${t.slug}`}
            className="rounded-full bg-sage px-4 py-2 text-[0.72rem] font-bold tracking-wide text-cream transition hover:bg-sage-deep"
          >
            Book Appointment
          </Link>
          <Link
            href={`/treatments/${t.slug}`}
            className="text-[0.72rem] font-bold tracking-wide text-brown underline-offset-4 transition hover:text-gold hover:underline"
          >
            Learn More →
          </Link>
        </div>
      </div>
    </article>
  );
}
